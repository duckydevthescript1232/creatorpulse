# CreatorPulse project rules

## Product

CreatorPulse is a real YouTube creator workspace, not a demo dashboard. Its job is to turn a creator's own channel evidence into useful next actions and to safely manage supported YouTube metadata after explicit authorization.

## Non-negotiable product principles

- Never substitute demo/sample channel data inside the authenticated product.
- Public `@handle` analysis is read-only. It may use only information actually available from public YouTube surfaces.
- Google/YouTube OAuth is required for authenticated YouTube Analytics and for title, description, or tag updates.
- A public YouTube handle never proves account ownership and never grants CreatorPulse admin rights.
- CreatorPulse account identity, CreatorPulse `ADMIN` role, and YouTube channel authorization are three separate systems.
- Never invent unavailable YouTube analytics, retention, keyword volume, trend data, sync success, payment state, or AI output.
- Derived scores and recommendations must say what evidence they use and expose confidence/limitations.
- YouTube writes happen only after an explicit user save/confirmation. Preserve current snippet metadata when updating one field.
- The authenticated product must always prefer a truthful unavailable/read-only state over fake content.

## Performance and interaction

- Navigation is UI-first, data-second: acknowledge the click immediately, show the destination shell/skeleton, and load data inside it.
- Keep the workspace sidebar/topbar mounted through `AppFrame`/`DashboardShell`; do not recreate the full shell per route.
- Prefetch likely workspace routes and use client-side navigation for internal pages.
- Do not block navigation on YouTube, database, analytics, or chart requests.
- Use cached/recent data immediately when safe, then revalidate in the background.
- Animations must be subtle and short (generally 120–180ms) and must never delay navigation.
- Respect both `prefers-reduced-motion` and the manual reduce-motion setting.
- Avoid full-page spinners and artificial delays. Prefer stable skeletons and local pending states.

## Architecture

- App Router pages live in `app/`; shared UI lives in `components/`.
- Business logic lives in `lib/`, grouped by domain. React components do not call Google or PayPal secrets directly.
- External data must be normalized before product logic consumes it.
- Sensitive operations remain server-side. Never expose OAuth tokens, encryption keys, OAuth client secrets, password hashes, or PayPal secrets to the browser or logs.
- Authenticate every user-specific mutation and enforce ownership server-side.
- Validate untrusted input at API boundaries and fail closed.
- Keep plan limits in `lib/entitlements/plans.ts` and ensure marketing/pricing claims match what the app actually enforces.
- The current UI is single-active-channel. Do not market multi-channel support until the product can select/manage multiple active channels.

## YouTube data rules

- Public channel analysis normalizes supported `youtube.com/@handle` and `/channel/UC...` URLs.
- OAuth synchronization paginates uploads and currently caps one synchronization at 500 videos for request safety.
- YouTube Data API video reads are batched within API limits.
- Authorized daily analytics are stored with full dates. Public mode must never pretend current video totals are historical daily channel views.
- Studio CSV import may add private metrics when supplied by the creator.
- Disconnect removes stored authorization credentials; previously synchronized data may remain read-only unless the user removes the workspace.

## Testing and quality

- Keep TypeScript strict and avoid `any` unless a framework boundary truly requires it.
- Run `npm run typecheck`, `npm run lint`, and `npm test` after meaningful changes.
- Run `npm run build` in a platform-compatible clean install before deployment.
- Add focused tests for auth separation, ownership, OAuth state/token crypto, YouTube metadata safety, navigation behavior, scoring, planner persistence, and source honesty.
- Verify empty, error, expired-auth, read-only, quota/partial-data, mobile, and reduced-motion states.
- Use semantic HTML, keyboard-accessible controls, visible focus, useful labels, and readable text sizes.

## Never regress to prototype behavior

Do not add fake buttons, fake loading delays, placeholder admin tools, mock analytics, or a hidden demo workspace to make a screen look complete. A feature must either work with real/local deterministic data, clearly explain the required connection/configuration, or be omitted until it is implemented.
