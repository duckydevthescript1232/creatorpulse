# CreatorPulse

CreatorPulse is a production-oriented YouTube creator workspace for channel analysis, planning, connected analytics, and safe metadata editing.

The authenticated product does **not** substitute a demo channel. It starts from a real public YouTube channel and can be upgraded to a verified connected workspace through Google/YouTube OAuth.

## What works

- Email/password CreatorPulse sessions with a server-side `ADMIN` role.
- Public YouTube `@handle` / channel URL analysis without OAuth.
- Google OAuth with PKCE, encrypted tokens, refresh-token handling, disconnect, and explicit YouTube metadata-editing scope.
- YouTube synchronization for channel data, up to 500 uploads per sync, and up to 365 days of daily YouTube Analytics data.
- Real video library with title/description/tag drafts and explicit `Save to YouTube` updates.
- Safe snippet merging so updating one metadata field does not unintentionally clear the others.
- Overview, Analytics, Growth Plan, Ideas, View Planner, Launch Lab, Settings, Help, and admin deployment status.
- Persisted production planner items with optimistic create/update/delete/reorder behavior.
- Channel-grounded deterministic ideas/recommendations with confidence and source limitations instead of fabricated trend claims.
- YouTube Studio CSV import for supported deeper metrics.
- PayPal subscription backend and plan entitlements.
- Persistent workspace shell, route prefetching, immediate route skeletons, short motion, compact-density preference, and manual reduced-motion preference.
- CSV workspace export for up to 500 loaded videos.

## Admin login setup

Copy `.env.example` to your local/deployment environment and set at minimum:

```text
APP_URL=
APP_SESSION_SECRET=
CREATORPULSE_ADMIN_EMAIL=
CREATORPULSE_ADMIN_PASSWORD_HASH=
```

Generate the password hash without putting the raw password in source control:

```bash
npm run admin:hash
```

Then set the printed hash as `CREATORPULSE_ADMIN_PASSWORD_HASH`. The matching email is assigned the server-side `ADMIN` role after successful password verification.

## YouTube connection

Public analysis works without Google credentials. To use verified daily analytics and edit real video metadata, configure:

```text
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
GOOGLE_REDIRECT_URI=
YOUTUBE_TOKEN_ENCRYPTION_KEY=
```

`APP_SESSION_SECRET` is also required by the OAuth state flow. The Google project must be configured with the same redirect URI used by CreatorPulse.

## Local development

1. Use Node.js 22.13+.
2. Copy `.env.example` to your local environment and configure the admin account.
3. Install dependencies from scratch with `npm ci`.
4. Run `npm run dev`.
5. Sign in, add your YouTube handle, and connect YouTube from Settings if you want live analytics/video editing.

## Quality checks

```bash
npm run typecheck
npm run lint
npm test
npm run build
```

Run the production build from a clean, platform-compatible dependency install. `node_modules` should never be copied between Windows and Linux because native Vinext/Rolldown bindings are platform-specific.

## Deployment requirements

- Configure a strong `APP_SESSION_SECRET` and `YOUTUBE_TOKEN_ENCRYPTION_KEY` outside source control.
- Configure the Google OAuth consent screen, redirect URI, and YouTube APIs before testing connected actions.
- Configure `CREATORPULSE_SUPPORT_EMAIL` before inviting other users.
- If billing is enabled, configure PayPal credentials/plan IDs and verify sandbox checkout + signed webhooks before switching to live mode.
- Run database migrations against the deployment database.
- Review Privacy/Terms for the deployment jurisdiction before public access.
- Test OAuth connect → sync → select video → edit metadata → save → reload against the real channel before relying on the deployment.

## Current intentional limits

- The current workspace UI manages one active channel at a time.
- A single YouTube sync caps at 500 uploads to keep request time bounded.
- Password recovery email is not implemented; a private owner deployment can rotate the configured admin password hash.
- Launch Lab saves its brief on the current device; Planner items are account-persisted.
- CreatorPulse recommendations are deterministic/channel-relative unless another provider is explicitly added. They do not pretend to know future views, private recommendation signals, or guaranteed rankings.

See `docs/BUILD_STATUS.md` and `docs/PRODUCTION_AUDIT.md` for the latest quality status.
