import { headers } from "next/headers";
import Link from "@/components/HardLink";
import { DashboardShell } from "@/components/app/DashboardShell";
import { getAuthenticatedViewer } from "@/lib/auth/viewer";
import { getWorkspace, workspaceShell } from "@/lib/workspace";
import { youtubeWriteScope } from "@/lib/youtube/scopes";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const viewer = await getAuthenticatedViewer(await headers());
  if (!viewer) return <DashboardShell active="Admin"><section className="product-empty"><h1>Authentication required</h1><p>Sign in before opening CreatorPulse administration.</p><Link className="button" href="/login?returnTo=/admin">Sign in</Link></section></DashboardShell>;
  const workspace = await getWorkspace(viewer);
  if (viewer.role !== "ADMIN") return <DashboardShell active="Admin" {...workspaceShell(workspace)}><section className="product-empty"><span>403 · PROTECTED</span><h1>Administrator access required</h1><p>Your account is authenticated, but it does not have the ADMIN database role.</p><Link className="button secondary" href="/dashboard">Return to dashboard</Link></section></DashboardShell>;

  const connection = workspace.connection;
  const canWrite = Boolean(connection?.scopes.includes(youtubeWriteScope));
  return <DashboardShell active="Admin" {...workspaceShell(workspace)}>
    <section className="inner-page-heading"><div><span className="eyebrow violet">Admin</span><h1>CreatorPulse system status</h1><p>Real server-verified status for this deployment. No placeholder administration tools are shown.</p></div><span className="admin-badge">ADMIN</span></section>
    <section className="admin-overview-grid">
      <article><span>ROLE VERIFICATION</span><h2>Database ADMIN</h2><p>{viewer.email} is authenticated and currently has the ADMIN database role.</p></article>
      <article><span>YOUTUBE CONNECTION</span><h2>{connection ? "Connected" : "Not connected"}</h2><p>{connection ? `${connection.channelTitle} · ${connection.syncStatus}${connection.lastSyncedAt ? ` · synced ${connection.lastSyncedAt.toLocaleString("en-US")}` : ""}` : "Connect YouTube in Settings before using private analytics or management actions."}</p></article>
      <article><span>METADATA ACCESS</span><h2>{canWrite ? "Write access granted" : "Read-only / unavailable"}</h2><p>{canWrite ? "The connected YouTube authorization includes the scope needed for confirmed metadata updates." : "Admin status never grants YouTube write access by itself."}</p></article>
      <article><span>WORKSPACE SOURCE</span><h2>{workspace.source ? workspace.source.sourceType === "oauth" ? "Verified YouTube" : "Public scan" : "No channel"}</h2><p>{workspace.source ? `${workspace.source.channelTitle} is the active CreatorPulse workspace.` : "Add a channel before using channel tools."}</p></article>
    </section>
  </DashboardShell>;
}
