import { headers } from "next/headers";
import Link from "@/components/HardLink";
import { DashboardShell } from "@/components/app/DashboardShell";
import { MetricCard } from "@/components/app/MetricCard";
import { PerformanceChart } from "@/components/app/PerformanceChart";
import { getAuthenticatedViewer } from "@/lib/auth/viewer";
import { compactNumber, formatSummary, topicSignals } from "@/lib/insights/channel";
import { getWorkspace, workspaceShell } from "@/lib/workspace";
import { planEntitlements } from "@/lib/entitlements/plans";

export const dynamic = "force-dynamic";

function sumDaily(rows: Array<{ label: string; value: number }>, start: number): number {
  return rows.slice(start).reduce((sum, row) => sum + Number(row.value || 0), 0);
}

export default async function AnalyticsPage({ searchParams }: { searchParams: Promise<{ days?: string }> }) {
  const viewer = await getAuthenticatedViewer(await headers());
  if (!viewer) return <DashboardShell active="Analytics"><section className="product-empty"><h1>Sign in to view analytics</h1><Link className="button" href="/login?returnTo=/analytics">Continue securely</Link></section></DashboardShell>;

  const [workspace, params] = await Promise.all([getWorkspace(viewer, { videoLimit: 500 }), searchParams]);
  const source = workspace.source;
  if (!source) return <DashboardShell active="Analytics" {...workspaceShell(workspace)}><section className="product-empty"><span>ANALYTICS</span><h1>Analyze a channel first</h1><p>CreatorPulse needs real uploads before it can build useful comparisons.</p><Link className="button" href="/channel-setup">Add your channel</Link></section></DashboardShell>;

  const requestedDays = Number(params.days ?? 28);
  const maxHistoryDays = planEntitlements[workspace.plan].historyDays;
  const supportedDays = [7, 28, 90, 365];
  const requestedSupported = supportedDays.includes(requestedDays) ? requestedDays : 28;
  const days = requestedSupported <= maxHistoryDays ? requestedSupported : Math.min(28, maxHistoryDays);
  const anchorMs = source.lastSyncedAt.getTime();
  const cutoff = anchorMs - Math.max(0, days - 1) * 86_400_000;
  const videos = workspace.videos.filter((video) => Date.parse(video.publishedAt) >= cutoff && video.views > 0);
  const formats = formatSummary(videos);
  const topics = topicSignals(videos);
  const sampledViews = videos.reduce((sum, video) => sum + video.views, 0);
  const totalEngagement = videos.reduce((sum, video) => sum + (video.likes ?? 0) + (video.comments ?? 0), 0);
  const engagementRate = sampledViews ? totalEngagement / sampledViews * 100 : 0;
  const leader = formats[0];
  const shortViews = formats.find((item) => item.format === "Short")?.views ?? 0;
  const shortShare = sampledViews ? Math.round(shortViews / sampledViews * 100) : 0;
  const sortedVideos = [...videos].sort((a, b) => b.views - a.views).slice(0, 5);

  const rawDaily = workspace.snapshot?.periodMetrics?.dailyViews ?? [];
  const dailyViews = rawDaily
    .map((row) => ({ date: row.label, label: "Daily views", value: Number(row.value || 0) }))
    .filter((row) => /^\d{4}-\d{2}-\d{2}$/.test(row.date) && Date.parse(row.date) >= cutoff)
    .sort((a, b) => Date.parse(a.date) - Date.parse(b.date));
  const hasDailyAnalytics = source.sourceType === "oauth" && dailyViews.length >= Math.min(days, 2);
  const channelViews = hasDailyAnalytics ? sumDaily(dailyViews.map(({ date, value }) => ({ label: date, value })), 0) : null;
  const watchMinutes28d = days === 28 ? workspace.snapshot?.periodMetrics?.watchMinutes28d : undefined;

  const chartPoints = hasDailyAnalytics
    ? dailyViews
    : videos.map((video) => ({ date: video.publishedAt, value: video.views, label: video.title }));

  return <DashboardShell active="Analytics" {...workspaceShell(workspace)}>
    <div className={`source-ribbon ${source.sourceType === "oauth" ? "" : "read-only"}`}><div><strong>{source.sourceType === "oauth" ? "Real YouTube analytics" : "Real public YouTube data"}</strong><span>{hasDailyAnalytics ? "Daily channel views come from your authorized YouTube Analytics data. Derived comparisons are labelled separately." : "Historical daily channel analytics are unavailable in public mode, so upload-level samples are labelled clearly."}</span></div><Link href="/settings">Manage data</Link></div>
    <section className="inner-page-heading"><div><span className="eyebrow">Channel analytics</span><h1>Performance, with the source made clear.</h1><p>Use real channel analytics when available and honest upload-level comparisons everywhere else.</p></div><nav className="period-control" aria-label="Analytics period">{supportedDays.map((value) => value <= maxHistoryDays ? <Link className={days === value ? "active" : ""} href={`/analytics?days=${value}`} key={value}>{value} days</Link> : <Link className="locked" href="/pricing" title="Upgrade to unlock this analytics range" key={value}>{value} days · Pro</Link>)}</nav></section>
    <section className="data-legend"><span><i className="real" />Real YouTube data</span><span><i className="derived" />CreatorPulse derived comparison</span></section>
    <section className="metric-grid">
      <MetricCard label={hasDailyAnalytics ? "Channel views" : "Sample views"} value={compactNumber(channelViews ?? sampledViews)} detail={hasDailyAnalytics ? `${dailyViews.length} daily YouTube Analytics rows in range` : `${videos.length} real uploads published in selected window`} />
      <MetricCard label="Public engagement" value={`${engagementRate.toFixed(1)}%`} detail="Available likes + comments divided by sampled video views" />
      <MetricCard label={watchMinutes28d !== undefined ? "Watch time" : "Strongest format"} value={watchMinutes28d !== undefined ? `${compactNumber(Math.round(watchMinutes28d / 60))}h` : leader?.format ?? "Not enough data"} detail={watchMinutes28d !== undefined ? "Real estimated watch hours · last 28 days" : leader ? `${compactNumber(leader.medianViews)} median sampled views` : "Not enough data"} />
      <MetricCard label="Data depth" value={workspace.latestImport ? "Studio+" : source.sourceType === "oauth" ? "YouTube" : "Public"} detail={workspace.latestImport ? "Imported Studio metrics included where available" : hasDailyAnalytics ? "Authorized daily analytics available" : "Unavailable metrics stay unavailable"} accent />
    </section>
    <PerformanceChart
      anchorDate={source.lastSyncedAt.toISOString()}
      points={chartPoints}
      fixedDays={days}
      title={hasDailyAnalytics ? "Daily channel views" : "Views by published upload"}
      description={hasDailyAnalytics ? "Real daily views from YouTube Analytics. Longer ranges are grouped only for chart readability." : "Public mode cannot reconstruct historical daily channel views. This fallback plots each sampled upload's current views by publish date."}
      emptyMessage={hasDailyAnalytics ? "Not enough daily analytics are available for this range yet." : "Not enough uploads were published in this range."}
    />
    <section className="analytics-grid"><article className="table-card"><div className="card-heading"><div><span>Top recent videos</span><h2>Uploads creating momentum</h2></div></div><div className="top-video-list">{sortedVideos.length ? sortedVideos.map((video, index) => <Link href={`/videos?video=${video.id}`} key={video.id}><span>0{index + 1}</span><div><strong>{video.title}</strong><small>{video.format} · {new Date(video.publishedAt).toLocaleDateString("en-US")}</small></div><b>{compactNumber(video.views)}</b></Link>) : <p className="empty-copy">No uploads were published in this selected period.</p>}</div></article><article className="format-card"><div className="card-heading"><div><span>Content comparison</span><h2>{leader ? `${leader.format} leads` : "Collecting signals"}</h2></div></div><div className="donut" style={{ background: `conic-gradient(var(--violet) ${shortShare}%, #292933 0)` }}><div><strong>{shortShare}%</strong><span>Shorts sample</span></div></div><dl>{formats.map((item) => <div key={item.format}><dt>{item.format}</dt><dd>{compactNumber(item.medianViews)} median</dd></div>)}</dl></article></section>
    <article className="table-card topic-signals"><div className="card-heading"><div><span>CreatorPulse derived</span><h2>Recurring topics earning attention</h2></div></div><div className="topic-table" role="table"><div className="topic-row header" role="row"><span>Signal</span><span>Uploads</span><span>Median views</span><span>Confidence</span></div>{topics.length ? topics.map((topic) => <div className="topic-row" role="row" key={topic.topic}><strong>{topic.topic}</strong><span>{topic.uploads}</span><span>{compactNumber(topic.medianViews)}</span><span>{topic.confidence}</span></div>) : <p className="empty-copy">More repeated title themes are needed.</p>}</div></article>
  </DashboardShell>;
}
