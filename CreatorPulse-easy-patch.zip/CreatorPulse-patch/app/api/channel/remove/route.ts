import { assertSameOrigin, getAuthenticatedViewer } from "@/lib/auth/viewer";
import { getActiveChannelSource, removeChannelWorkspace } from "@/lib/youtube/public-repository";
import { decryptToken } from "@/lib/youtube/crypto";
import { getGoogleOAuthConfig, revokeGoogleToken } from "@/lib/youtube/oauth";
import { getActiveConnection } from "@/lib/youtube/repository";

export const dynamic = "force-dynamic";

export async function POST(request: Request): Promise<Response> {
  try { assertSameOrigin(request); } catch { return new Response("Invalid request origin.", { status: 403 }); }
  const viewer = await getAuthenticatedViewer(request.headers);
  if (!viewer) return new Response("Authentication required.", { status: 401 });
  const source = await getActiveChannelSource(viewer.id);
  if (!source) return Response.redirect(new URL("/channel-setup?channel=removed", request.url), 303);

  const connection = await getActiveConnection(viewer.id);
  if (connection?.channelId === source.channelId) {
    const config = getGoogleOAuthConfig();
    if (config) {
      try {
        const encrypted = connection.encryptedRefreshToken ?? connection.encryptedAccessToken;
        await revokeGoogleToken(await decryptToken(encrypted, config.tokenEncryptionKey));
      } catch (error) {
        console.warn("Google token revocation was unavailable while removing workspace; local credentials will still be deleted", error instanceof Error ? error.message : "Unknown error");
      }
    }
  }

  await removeChannelWorkspace(viewer.id, source.channelId);
  return Response.redirect(new URL("/channel-setup?channel=removed", request.url), 303);
}
