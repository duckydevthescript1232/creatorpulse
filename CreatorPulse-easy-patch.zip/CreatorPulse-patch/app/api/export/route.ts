import { getAuthenticatedViewer } from "@/lib/auth/viewer";
import { getWorkspace } from "@/lib/workspace";

export const dynamic = "force-dynamic";

function cell(value: unknown): string { const text = String(value ?? ""); return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text; }

export async function GET(request: Request): Promise<Response> {
  const viewer = await getAuthenticatedViewer(request.headers); if (!viewer) return new Response("Authentication required.", { status: 401 });
  const workspace = await getWorkspace(viewer, { videoLimit: 500 }); if (!workspace.source) return new Response("Analyze a channel first.", { status: 409 });
  const rows = [["video_id", "title", "published_at", "format", "views", "likes", "comments", "privacy_status"], ...workspace.videos.map((video) => [video.id, video.title, video.publishedAt, video.format, video.views, video.likes ?? "", video.comments ?? "", video.privacyStatus ?? "unavailable"])];
  return new Response(rows.map((row) => row.map(cell).join(",")).join("\n"), { headers: { "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="creatorpulse-${workspace.source.channelId}.csv"`, "cache-control": "private, no-store" } });
}
