import { assertSameOrigin, getAuthenticatedViewer } from "@/lib/auth/viewer";
import { upsertOAuthChannelSource } from "@/lib/youtube/public-repository";
import { saveSnapshot, saveVideos, updateConnectionStatus } from "@/lib/youtube/repository";
import { synchronizeYouTube } from "@/lib/youtube/sync";
import { getValidYouTubeAccess, YouTubeConnectionError } from "@/lib/youtube/token-service";

export const dynamic = "force-dynamic";

export async function POST(request: Request): Promise<Response> {
  try { assertSameOrigin(request); } catch { return Response.json({ error: "Invalid request origin." }, { status: 403 }); }
  const viewer = await getAuthenticatedViewer(request.headers);
  if (!viewer) return Response.json({ error: "Authentication required." }, { status: 401 });
  try {
    const { connection, accessToken } = await getValidYouTubeAccess(viewer.id);
    const synced = await synchronizeYouTube(accessToken);
    if (synced.channel.id !== connection.channelId) return Response.json({ error: "The authorized channel changed. Reconnect YouTube." }, { status: 409 });
    await Promise.all([
      saveSnapshot(viewer.id, { channelId: synced.channel.id, subscribers: synced.channel.subscribers, views: synced.channel.totalViews, uploads: synced.channel.uploadCount, availableMetrics: ["subscribers", "totalViews", "uploads", ...Object.keys(synced.periodMetrics)], periodMetrics: synced.periodMetrics }),
      saveVideos(viewer.id, synced.channel.id, synced.recentVideos),
      upsertOAuthChannelSource(viewer.id, synced.channel, synced.analyticsError ? "partial" : "ready", synced.analyticsError),
      updateConnectionStatus(viewer.id, synced.channel.id, synced.analyticsError ? "partial" : "ready", synced.analyticsError),
    ]);
    return Response.json({ ok: true, videos: synced.recentVideos.length, truncated: synced.videoSyncTruncated, partial: Boolean(synced.analyticsError) });
  } catch (error) {
    const message = error instanceof YouTubeConnectionError && error.code === "reconnect_required" ? "YouTube authorization expired. Reconnect to continue." : error instanceof Error ? error.message : "YouTube synchronization failed.";
    return Response.json({ error: message }, { status: error instanceof YouTubeConnectionError ? 409 : 502 });
  }
}
