import { headers } from "next/headers";
import Link from "@/components/HardLink";
import { Logo } from "@/components/brand/Logo";
import { getAuthenticatedViewer } from "@/lib/auth/viewer";

export const dynamic = "force-dynamic";

const messages: Record<string, { title: string; copy: string }> = {
  invalid_url: { title: "Use a channel URL", copy: "Enter an @handle, youtube.com/@handle, or youtube.com/channel/UC… URL." },
  not_found: { title: "Channel not found", copy: "CreatorPulse could not resolve that public channel. Check the handle and try again." },
  temporarily_unavailable: { title: "YouTube is temporarily unavailable", copy: "Public channel data could not be read right now. Nothing was saved; please retry shortly." },
  connect_first: { title: "Connect a public channel first", copy: "A Studio CSV needs a channel to attach its private metrics to." },
  removed: { title: "Channel removed", copy: "The channel is no longer active in this workspace." },
};

export default async function ChannelSetupPage({ searchParams }: { searchParams: Promise<{ channel?: string }> }) {
  const viewer = await getAuthenticatedViewer(await headers());
  if (!viewer) return <main className="account-auth-page"><section className="account-auth-brand"><Logo /><div><span>CHANNEL SETUP</span><h1>Sign in before adding a channel.</h1><p>A public YouTube handle is not authentication and never proves channel ownership.</p></div></section><section className="account-auth-form"><div className="account-login-card"><h2>CreatorPulse account required</h2><Link className="button full" href="/login?returnTo=/channel-setup">Sign in</Link></div></section></main>;
  const message = messages[(await searchParams).channel ?? ""];
  return <main className="auth-page no-api-auth"><section className="auth-panel"><Logo /><div className="auth-copy"><span>CHANNEL ADDED ≠ CHANNEL VERIFIED</span><h1>Start with your public channel.</h1><p>Paste a YouTube @handle or channel URL. CreatorPulse stores the resolved permanent channel ID and uses public evidence for analysis.</p></div><div className="auth-proof"><strong>YouTube management stays protected</strong><p>Editing titles, descriptions, or tags still requires the proper Google/YouTube OAuth authorization for that channel.</p></div></section><section className="login-panel"><div className="login-card channel-connect-card"><span className="eyebrow">What’s your YouTube channel?</span><h2>Add a public channel</h2><p>This adds the channel for analysis. It does not claim or verify ownership.</p>{message && <div className="connection-notice error"><strong>{message.title}</strong><span>{message.copy}</span></div>}<form className="channel-url-form" action="/api/channel/analyze" method="post"><label htmlFor="channel-url">YouTube @handle or channel URL</label><div><input id="channel-url" name="channel" placeholder="@yourhandle or youtube.com/@yourhandle" maxLength={250} required autoComplete="url" /><button className="button" type="submit">Continue <span>→</span></button></div><small>Public data only · CreatorPulse stores the resolved channel ID</small></form><div className="connection-methods"><div><span>01</span><p><strong>Channel added</strong>Public uploads, views, formats, titles, and creator-relative performance.</p></div><div><span>02</span><p><strong>Channel verified</strong>Google OAuth is required for private analytics and authenticated YouTube management actions.</p></div></div><Link className="button secondary full" href="/dashboard">Skip for now</Link></div></section></main>;
}
