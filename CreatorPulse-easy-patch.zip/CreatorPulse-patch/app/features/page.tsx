import Link from "@/components/HardLink";
import { MarketingFooter } from "@/components/marketing/MarketingFooter";
import { MarketingHeader } from "@/components/marketing/MarketingHeader";

const features = [
  ["Daily Growth Plan", "A ranked daily move with a concept, titles, hook direction, format guidance, and evidence."],
  ["Video Analyzer", "Channel-relative scoring that separates topic, format, engagement, and subscriber conversion signals."],
  ["View Planner", "A zero-credit weekly plan for topic, format, length, packaging, hook, and the next measurable experiment."],
  ["Idea Generator", "Ideas ranked for a selected goal using topic fit, recent repetition, format, and channel scale."],
  ["Format Intelligence", "Separate baselines for Shorts, long-form, and streams so comparisons remain meaningful."],
  ["Confidence System", "Low, Medium, or High confidence makes sparse evidence visible instead of hiding uncertainty."],
];

export default function FeaturesPage() {
  return <div className="marketing-page"><MarketingHeader /><main><section className="subpage-hero"><div className="container"><span>PRODUCT</span><h1>From channel data to a <em>clear next move.</em></h1><p>CreatorPulse is designed around decisions, not dashboards for their own sake.</p></div></section><section className="section"><div className="container feature-detail-grid">{features.map((feature, index) => <article key={feature[0]}><span>0{index + 1}</span><h2>{feature[0]}</h2><p>{feature[1]}</p></article>)}</div></section><section className="simple-cta"><div className="container"><h2>Use CreatorPulse with your own channel.</h2><p>Sign in, add your YouTube @handle, then connect YouTube when you want verified analytics and metadata editing.</p><Link className="button" href="/login?returnTo=/channel-setup">Start with my channel →</Link></div></section></main><MarketingFooter /></div>;
}
