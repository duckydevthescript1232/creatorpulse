import Link from "@/components/HardLink";
import { Logo } from "@/components/brand/Logo";

export default function ForgotPasswordPage() {
  return <main className="account-auth-page">
    <section className="account-auth-brand"><Logo /><div><span>ACCOUNT RECOVERY</span><h1>Password recovery is not enabled yet.</h1><p>CreatorPulse will never pretend to send a recovery email when no mail provider is configured.</p></div></section>
    <section className="account-auth-form"><div className="account-login-card"><span className="eyebrow violet">Password help</span><h2>Use your configured account credentials</h2><p>If this is your private CreatorPulse deployment, update the administrator password hash in your secure server environment and redeploy. Do not put a password or hash in client-side code.</p><Link className="button full" href="/login">Back to sign in</Link></div></section>
  </main>;
}
