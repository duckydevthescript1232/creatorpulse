import { headers } from "next/headers";
import Link from "@/components/HardLink";
import { ConfidenceBadge } from "@/components/app/ConfidenceBadge";
import { CreatorPlanQuestionnaire } from "@/components/app/CreatorPlanQuestionnaire";
import { DashboardShell } from "@/components/app/DashboardShell";
import { ScoreRing } from "@/components/app/ScoreRing";
import { getAuthenticatedViewer } from "@/lib/auth/viewer";
import { compactNumber, growthRecommendation } from "@/lib/insights/channel";
import { getCreatorPlanProfile } from "@/lib/planning/profile";
import { planEntitlements } from "@/lib/entitlements/plans";
import { performanceRatio } from "@/lib/scoring/engine";
import { getWorkspace, workspaceShell } from "@/lib/workspace";

export const dynamic = "force-dynamic";

export default async function GrowthPlanPage() {
  const viewer = await getAuthenticatedViewer(await headers());
  if (!viewer) return <DashboardShell active="Growth Plan"><section className="product-empty"><span>GROWTH PLAN</span><h1>Sign in to build your evidence-led growth plan</h1><p>Your recommendations use the channel history in your private workspace.</p><Link className="button" href="/login?returnTo=/growth-plan">Continue securely</Link></section></DashboardShell>;

  const [workspace, creatorProfile] = await Promise.all([getWorkspace(viewer), getCreatorPlanProfile(viewer.id)]);
  const plan = growthRecommendation(workspace.videos);

  if (!workspace.source || !plan) return <DashboardShell active="Growth Plan" {...workspaceShell(workspace)}>
    <CreatorPlanQuestionnaire initialProfile={creatorProfile} />
    <section className="product-empty"><span>GROWTH PLAN</span><h1>Your next move needs evidence</h1><p>Your creator brief is ready. Add a channel with at least three recent public uploads to combine it with real performance evidence.</p><Link className="button" href="/channel-setup">Analyze channel</Link></section>
  </DashboardShell>;

  if (!planEntitlements[workspace.plan].dailyGrowthPlan) return <DashboardShell active="Growth Plan" {...workspaceShell(workspace)}>
    <CreatorPlanQuestionnaire initialProfile={creatorProfile} />
    <section className="product-empty upgrade-state"><span>PRO GROWTH PLAN</span><h1>Your free workspace already has the next-action signal</h1><p>Upgrade to Pro to turn that signal into the full prioritized Growth Plan with controlled experiments, creator-brief constraints, and what-not-to-repeat guidance.</p><div className="empty-actions"><Link className="button" href="/pricing">Compare plans</Link><Link className="button secondary" href="/dashboard">Use my free next action</Link></div></section>
  </DashboardShell>;

  const comparableVideos = workspace.videos.filter((video) => video.views > 0);
  const weakest = comparableVideos.toSorted((a, b) => performanceRatio(a, workspace.videos) - performanceRatio(b, workspace.videos))[0];
  const recentCutoff = workspace.source.lastSyncedAt.getTime() - 28 * 86_400_000;
  const recentUploads = workspace.videos.filter((video) => Date.parse(video.publishedAt) >= recentCutoff).length;
  const consistency = recentUploads >= 4 ? "Strong" : recentUploads >= 2 ? "Building" : "Needs attention";
  const profileFocus = creatorProfile ? `Goal: ${creatorProfile.primaryGoal.replaceAll("_", " ")} · Audience: ${creatorProfile.targetAudience} · ${creatorProfile.weeklyUploads} upload${creatorProfile.weeklyUploads === 1 ? "" : "s"}/week within ${creatorProfile.weeklyHours} hours` : null;
  const challengeTest = creatorProfile?.biggestChallenge === "hooks" ? "Write three opening hooks before scripting and choose the clearest promise."
    : creatorProfile?.biggestChallenge === "retention" ? "Move the first payoff earlier and remove setup that does not serve it."
      : creatorProfile?.biggestChallenge === "packaging" ? "Create three title/thumbnail promise combinations before production."
        : creatorProfile?.biggestChallenge === "consistency" ? `Keep the concept achievable inside your ${creatorProfile.weeklyHours}-hour weekly production budget.`
          : "Turn the proven audience promise into three distinct follow-up concepts before choosing one.";

  return <DashboardShell active="Growth Plan" {...workspaceShell(workspace)}>
    <div className="source-ribbon"><div><strong>Generated from your channel evidence</strong><span>{workspace.videos.length} uploads compared by format.{profileFocus ? ` Creator brief applied: ${profileFocus}.` : " Add your creator brief to constrain the recommendation."}</span></div><Link href="/analytics">Inspect analytics</Link></div>
    <section className="inner-page-heading"><div><span className="eyebrow">Growth plan</span><h1>Your focused growth system.</h1><p>Priorities, evidence, controlled experiments, and the signals to avoid repeating.</p></div><span className="date-stamp">Updated {workspace.source.lastSyncedAt.toLocaleDateString("en", { month: "long", day: "numeric" })}</span></section>
    <CreatorPlanQuestionnaire initialProfile={creatorProfile} />
    <article className="growth-plan-card detailed">
      <div className="plan-topline"><span>PRIORITY 01 · HIGHEST-LEVERAGE OPPORTUNITY</span><ConfidenceBadge level={plan.score.confidence} /></div>
      <div className="plan-grid"><div className="plan-copy"><span className="eyebrow violet">Repeat the audience promise—not the exact upload</span><h2>{plan.headline}</h2><p>{plan.explanation}{creatorProfile ? ` This version is constrained for ${creatorProfile.targetAudience} and your ${creatorProfile.primaryGoal} goal.` : ""}</p><div className="concept-box"><span>Controlled experiment</span><strong>{plan.experiment} {challengeTest}</strong></div><div className="plan-details-grid"><div><span>Content type to focus on</span><strong>{creatorProfile?.preferredFormats.includes(plan.best.format) ? plan.best.format : creatorProfile?.preferredFormats[0] ?? plan.best.format}</strong></div><div><span>Topic worth repeating</span><strong>{plan.topic} · {plan.ratio.toFixed(1)}× baseline</strong></div>{creatorProfile && <><div><span>Target viewer</span><strong>{creatorProfile.targetAudience}</strong></div><div><span>Sustainable cadence</span><strong>{creatorProfile.weeklyUploads}/week · {creatorProfile.weeklyHours}h available</strong></div></>}</div><div className="title-directions"><span>Recommended packaging tests</span><ol><li>A direct sequel with a genuinely new outcome</li><li>The same topic under a harder constraint</li><li>A lesson learned that challenges the original expectation</li></ol></div></div><div className="plan-score"><ScoreRing score={plan.score.score} confidence={plan.score.confidence} /><span>Opportunity score</span><small>CreatorPulse derived</small></div></div>
      <div className="evidence-row"><div><strong>{plan.ratio.toFixed(1)}×</strong><span>Format-relative views</span></div><div><strong>{compactNumber(plan.best.views)}</strong><span>Winning upload views</span></div><div><strong>{plan.best.format}</strong><span>Recommended format</span></div></div>
    </article>
    <section className="growth-plan-matrix"><article><span>UPLOAD CONSISTENCY</span><h3>{consistency}</h3><p>{recentUploads} uploads in the last 28 days. {recentUploads < 2 ? "Choose a sustainable next publish date before expanding the plan." : "Keep the cadence stable while testing one creative variable."}</p></article><article><span>WHAT APPEARS NOT TO WORK</span><h3>{weakest ? weakest.title : "Not enough data"}</h3><p>{weakest ? `This upload reached ${performanceRatio(weakest, workspace.videos).toFixed(1)}× its format baseline. Do not repeat its packaging unchanged.` : "More comparable uploads are required."}</p></article><article><span>MEASUREMENT RULE</span><h3>Compare like with like</h3><p>Judge Shorts, long-form videos, and streams against their own recent baselines—not against one another.</p></article></section>
  </DashboardShell>;
}
