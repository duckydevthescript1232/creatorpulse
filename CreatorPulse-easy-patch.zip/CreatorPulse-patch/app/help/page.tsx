import Link from "@/components/HardLink";
import { DashboardShell } from "@/components/app/DashboardShell";

const faqs = [
  ["How do I add a YouTube channel?", "Sign in to CreatorPulse, open Add or refresh channel, and enter an @handle or channel URL. That creates a public read-only workspace. Connect YouTube from Settings when you want verified analytics sync and video-management access."],
  ["Can CreatorPulse edit my videos?", "Yes, after you explicitly connect and authorize the matching YouTube channel. CreatorPulse can update supported metadata such as title, description, and tags only when you confirm Save to YouTube. It never publishes or deletes a video automatically."],
  ["How do I add deeper analytics?", "A connected channel can sync supported YouTube Analytics metrics. You can also import supported YouTube Studio Advanced Mode CSV files in Settings for additional evidence."],
  ["What is a derived score?", "It is a CreatorPulse calculation made from available channel data. It never represents an official YouTube score, and the UI should explain the evidence behind it."],
  ["Why is confidence low?", "The recommendation has a small sample or fewer available metrics. Treat it as a hypothesis to test, not a certainty."],
  ["How does View Planner work?", "It finds a strong format-relative upload signal, then builds a topic, packaging, hook, duration, and measurement plan from your own channel history."],
  ["How are paid plans activated?", "CreatorPulse sends you to PayPal for approval, verifies the returned subscription, and uses signed webhooks to keep access in sync. You can cancel from Settings."],
] as const;

export default function HelpPage() {
  return <DashboardShell active="Help"><section className="inner-page-heading"><div><span className="eyebrow">Help center</span><h1>Clear answers, inspectable recommendations</h1><p>Understand exactly which data CreatorPulse can use and what each action changes.</p></div></section><section className="help-layout"><div className="help-faq"><span className="section-kicker">COMMON QUESTIONS</span>{faqs.map(([question, answer]) => <details key={question}><summary>{question}<span>+</span></summary><p>{answer}</p></details>)}</div><aside className="help-sidebar"><article><span>CHANNEL SETUP</span><h2>Add your @handle</h2><p>Start with a public read-only channel workspace.</p><Link className="button button-small" href="/channel-setup">Add or refresh channel</Link></article><article><span>FULL YOUTUBE ACCESS</span><h2>Verify your channel</h2><p>Connect YouTube for supported analytics and confirmed metadata updates.</p><Link className="button button-small secondary" href="/settings#youtube">Open YouTube settings</Link></article><article><span>BILLING</span><h2>Plans & PayPal</h2><p>Compare allowances or manage an existing subscription.</p><Link href="/pricing">View all plans →</Link></article></aside></section></DashboardShell>;
}
