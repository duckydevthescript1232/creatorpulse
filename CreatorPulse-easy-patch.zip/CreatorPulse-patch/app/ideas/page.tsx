import { headers } from "next/headers";
import Link from "@/components/HardLink";
import { DashboardShell } from "@/components/app/DashboardShell";
import { IdeasWorkspace } from "@/components/app/IdeasWorkspace";
import { getAuthenticatedViewer } from "@/lib/auth/viewer";
import { generateIdeas } from "@/lib/insights/channel";
import { getWorkspace, workspaceShell } from "@/lib/workspace";

export const dynamic = "force-dynamic";

export default async function IdeasPage({ searchParams }: { searchParams: Promise<{ goal?: string }> }) {
  const viewer = await getAuthenticatedViewer(await headers());
  if (!viewer) return <DashboardShell active="Ideas"><section className="product-empty"><span>IDEA WORKSPACE</span><h1>Sign in to generate channel-backed ideas</h1><p>Your directions use the real upload history in your private workspace.</p><Link className="button" href="/login?returnTo=/ideas">Continue securely</Link></section></DashboardShell>;
  const workspace = await getWorkspace(viewer); const goal = (await searchParams).goal ?? "views"; const ideas = generateIdeas(workspace.videos, goal);
  if (!workspace.source || !ideas.length) return <DashboardShell active="Ideas" {...workspaceShell(workspace)}><section className="product-empty"><span>IDEA WORKSPACE</span><h1>Ideas improve when they know your history</h1><p>Analyze a channel to generate ranked, evidence-linked directions.</p><Link className="button" href="/channel-setup">Analyze channel</Link></section></DashboardShell>;
  return <DashboardShell active="Ideas" {...workspaceShell(workspace)}><div className="source-ribbon"><div><strong>Channel-backed idea engine</strong><span>No invented trends, search volume, or paid AI calls.</span></div><Link href="/view-planner">Open production pipeline</Link></div><section className="inner-page-heading"><div><span className="eyebrow">Idea workspace</span><h1>Directions with a reason to exist.</h1><p>Ranked from your strongest recurring signals and ready to move into production.</p></div><form className="goal-select" method="get"><label htmlFor="goal">Primary goal</label><div><select id="goal" name="goal" defaultValue={goal}><option value="views">More views</option><option value="subscribers">More subscribers</option><option value="retention">Better retention</option></select><button type="submit">Update</button></div></form></section><IdeasWorkspace ideas={ideas} /></DashboardShell>;
}
