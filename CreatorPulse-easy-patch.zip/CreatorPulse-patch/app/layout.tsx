import type { Metadata } from "next";
import { headers } from "next/headers";
import { Geist, Geist_Mono } from "next/font/google";
import { AppFrame } from "@/components/app/AppFrame";
import { getAuthenticatedViewer } from "@/lib/auth/viewer";
import { getWorkspaceShell } from "@/lib/workspace";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://creatorpulse-growth.damianschenk24.chatgpt.site"),
  title: {
    default: "CreatorPulse V2 — Know what to post next",
    template: "%s — CreatorPulse",
  },
  description: "Real YouTube channel evidence, safe metadata editing, and a zero-credit production planner.",
  openGraph: {
    title: "CreatorPulse V2 — Know what to post next.",
    description: "Real channel evidence. Safe YouTube editing. Zero AI credits.",
    type: "website",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "CreatorPulse creator intelligence dashboard" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "CreatorPulse V2 — Know what to post next.",
    description: "Real channel evidence. Safe YouTube editing. Zero AI credits.",
    images: ["/og.png"],
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  let shell: Awaited<ReturnType<typeof getWorkspaceShell>> | undefined;
  try {
    const viewer = await getAuthenticatedViewer(await headers());
    if (viewer) shell = await getWorkspaceShell(viewer);
  } catch {
    shell = undefined;
  }
  return (
    <html lang="en">
      <body className={`${geistSans.variable} ${geistMono.variable}`}>
        <AppFrame shell={shell ?? {}}>{children}</AppFrame>
      </body>
    </html>
  );
}
