export default function Loading() {
  return <section className="route-skeleton global-route-skeleton" aria-label="Loading CreatorPulse" aria-live="polite"><header><div><span className="eyebrow violet">CreatorPulse</span><h1>Loading workspace</h1><p>Preparing the page while keeping navigation responsive.</p></div><span className="route-loading-chip"><i />Loading</span></header><div className="route-skeleton-metrics">{[0,1,2,3].map((item) => <article key={item}><span /><strong /><small /></article>)}</div><div className="route-skeleton-panel"><span /><span /><span /><span /></div></section>;
}
