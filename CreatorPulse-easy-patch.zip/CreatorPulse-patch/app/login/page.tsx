import { headers } from "next/headers";
import Link from "@/components/HardLink";
import { Logo } from "@/components/brand/Logo";
import { LoginForm } from "@/components/auth/LoginForm";
import { getAuthenticatedViewer } from "@/lib/auth/viewer";

export const dynamic = "force-dynamic";

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ returnTo?: string; signedOut?: string }> }) {
  const viewer = await getAuthenticatedViewer(await headers());
  const params = await searchParams;
  const returnTo = params.returnTo?.startsWith("/") && !params.returnTo.startsWith("//") ? params.returnTo : null;
  const destination = returnTo ?? "/dashboard";

  return <main className="account-auth-page">
    <section className="account-auth-brand">
      <Logo />
      <div><span>CREATOR INTELLIGENCE</span><h1>Your YouTube workspace, protected by your CreatorPulse account.</h1><p>Use one secure email-and-password account for your channel workspace. YouTube permissions remain separate and are only requested when you connect your channel.</p></div>
      <div className="auth-security-note"><i /><p><strong>Secure by design</strong>Your CreatorPulse identity, database role, and YouTube authorization are checked independently.</p></div>
    </section>
    <section className="account-auth-form">
      <div className="account-login-card">
        <span className="eyebrow violet">CreatorPulse account</span>
        <h2>{viewer ? `Welcome, ${viewer.name}` : "Sign in"}</h2>
        <p>{viewer ? "Your CreatorPulse session is active. Continue without signing in again." : "Enter your CreatorPulse email and password."}</p>
        {params.signedOut && <div className="auth-signed-out">You have been signed out.</div>}
        {viewer ? <>
          <Link className="button full" href={destination}>Continue to CreatorPulse</Link>
          <Link className="button secondary full" href="/channel-setup">Add or refresh a channel</Link>
        </> : <LoginForm returnTo={returnTo} />}
        <small>By continuing, you agree to the <Link href="/terms">Terms</Link> and <Link href="/privacy">Privacy Policy</Link>.</small>
      </div>
    </section>
  </main>;
}
