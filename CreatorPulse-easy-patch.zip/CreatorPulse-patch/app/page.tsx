import Link from "@/components/HardLink";
import { MarketingFooter } from "@/components/marketing/MarketingFooter";
import { MarketingHeader } from "@/components/marketing/MarketingHeader";

const featureCards = [
  { number: "01", label: "Daily Growth Plan", title: "Know what to post next.", copy: "A ranked recommendation grounded in your topics, formats, and recent performance—not a generic idea list." },
  { number: "02", label: "Video Analyzer", title: "Understand why videos win.", copy: "Compare each upload with the right channel-relative baseline and see the strongest and weakest factors." },
  { number: "03", label: "View Planner", title: "Build a better view experiment.", copy: "Turn your strongest upload signal into a weekly topic, format, title, hook, and measurement plan—without AI credits." },
];

export default function Home() {
  return (
    <div className="marketing-page">
      <MarketingHeader />
      <main>
        <section className="hero">
          <div className="hero-glow" />
          <div className="container hero-grid">
            <div className="hero-copy">
              <div className="announcement"><span>New</span> Your channel’s daily action plan <b>→</b></div>
              <h1>Stop guessing what to <em>upload.</em></h1>
              <p>CreatorPulse studies your YouTube channel and turns performance data into a clear, personalized growth plan.</p>
              <div className="hero-channel-form hero-channel-cta"><span className="hero-channel-label">Start with your CreatorPulse account</span><div><Link className="button" href="/login?returnTo=/channel-setup">Sign in and add your channel <span>→</span></Link></div><small>Add an @handle for public analysis, then verify with YouTube when you want management tools.</small></div>
              <a className="hero-how-link" href="#how-it-works">See how it works ↓</a>
              <div className="trust-row"><div className="avatar-stack"><span>AJ</span><span>MK</span><span>SL</span></div><p><strong>Built for the next decision,</strong><br />not another wall of charts.</p></div>
            </div>
            <div className="hero-product" aria-label="CreatorPulse dashboard preview">
              <div className="preview-top"><div className="preview-dots"><i /><i /><i /></div><span>creatorpulse.app/dashboard</span></div>
              <div className="preview-body">
                <div className="preview-sidebar"><div className="mini-mark"><i /><i /><i /></div>{[1,2,3,4,5,6].map((item) => <span className={item === 1 ? "active" : ""} key={item} />)}</div>
                <div className="preview-main">
                  <div className="preview-head"><div><small>GOOD MORNING, DAMIAN</small><strong>Here’s your best move today.</strong></div><span className="demo-chip">Product preview</span></div>
                  <div className="preview-metrics">{[["Subscribers","18.4K","+3.9%"],["28-day views","81.4K","+28%"],["Growth score","82","Strong"]].map((item) => <div key={item[0]}><span>{item[0]}</span><strong>{item[1]}</strong><small>{item[2]}</small></div>)}</div>
                  <div className="preview-plan"><div className="preview-plan-copy"><span>TODAY’S #1 OPPORTUNITY</span><strong>Create another Roblox horror Short</strong><p>This topic earns 3.8× your recent Shorts median.</p><div className="preview-evidence"><i /><i /><i /></div></div><div className="preview-score"><span>92</span><small>/ 100</small></div></div>
                  <div className="preview-chart"><div><span>Channel momentum</span><strong>Moving in the right direction</strong></div><div className="mini-bars">{[32,44,38,55,51,68,64,78,74,88,82,100].map((height, index) => <i style={{ height: `${height}%` }} key={index} />)}</div></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="signal-strip"><div className="container"><span>CHANNEL-RELATIVE INTELLIGENCE</span><i /><span>SHORTS + LONG-FORM</span><i /><span>EXPLAINABLE RECOMMENDATIONS</span><i /><span>DATA CONFIDENCE</span></div></section>

        <section className="section" id="how-it-works">
          <div className="container"><div className="section-kicker">Meet your evidence-led view planner</div><div className="section-heading"><h2>Your numbers already know what worked. <span>CreatorPulse turns that into a test.</span></h2><p>We organize your channel history around the decisions that actually matter: what to repeat, what to fix, and what to test next.</p></div>
            <div className="feature-grid">{featureCards.map((feature) => <article className="feature-card" key={feature.number}><span className="feature-number">{feature.number}</span><small>{feature.label}</small><h3>{feature.title}</h3><p>{feature.copy}</p><Link href="/features">Explore feature <span>→</span></Link></article>)}</div>
          </div>
        </section>

        <section className="section intelligence-section"><div className="container intelligence-grid"><div className="intelligence-copy"><div className="section-kicker">Your data. Your strategy.</div><h2>Benchmarks built around <em>your</em> channel.</h2><p>A view count means little without context. CreatorPulse compares Shorts with Shorts, long-form with long-form, and every upload with your normal range.</p><ul><li><i>01</i><span><strong>Format-aware baselines</strong>Never judge a 30-second Short against a 30-minute upload.</span></li><li><i>02</i><span><strong>Explainable scores</strong>See the factors and confidence behind every CreatorPulse score.</span></li><li><i>03</i><span><strong>Evidence, not certainty</strong>Recommendations get more confident only as useful data grows.</span></li></ul></div><div className="signal-card"><div className="signal-card-head"><span>WHY THIS WORKED</span><b>High confidence</b></div><h3>“3 Roblox Games That Get Dark Fast”</h3><div className="signal-stat"><strong>3.2×</strong><span>your typical Short views</span></div><div className="signal-lines"><div><span>Topic fit</span><i><b style={{ width: "91%" }} /></i><strong>91</strong></div><div><span>Engagement</span><i><b style={{ width: "84%" }} /></i><strong>84</strong></div><div><span>Subscriber gain</span><i><b style={{ width: "79%" }} /></i><strong>79</strong></div></div><p><span>SO WHAT?</span> Build the next Short around the same emotional promise, but reveal the first strange moment earlier.</p></div></div></section>

        <section className="section format-section"><div className="container"><div className="section-kicker centered">One strategy, both formats</div><h2>Built for Shorts <span>and</span> long-form.</h2><p className="section-lead">Different formats create different signals. CreatorPulse keeps each comparison honest.</p><div className="format-grid"><article><span>SHORTS INTELLIGENCE</span><h3>Spot repeatable hooks before momentum fades.</h3><div className="format-visual short"><div><small>0:00</small><strong>Don’t play this alone.</strong></div><p><b>+31%</b> stronger opening pattern</p></div></article><article><span>LONG-FORM INTELLIGENCE</span><h3>Find the ideas that earn sustained attention.</h3><div className="format-visual long"><div className="retention-line"><i /><i /><i /><i /><i /><i /><i /><i /></div><p><b>12:42</b> ideal recent duration range</p></div></article></div></div></section>

        <section className="pricing-preview"><div className="container pricing-preview-inner"><div><div className="section-kicker">Start with your own channel</div><h2>Clarity before your next upload.</h2><p>Connect one channel for free. Upgrade when deeper history and daily intelligence earn a place in your workflow.</p></div><div className="price-mini"><span>FREE</span><strong>€0<small>/ forever</small></strong><ul><li>1 YouTube channel</li><li>Basic dashboard</li><li>Weekly View Planner</li></ul><Link className="button" href="/login">Start free</Link></div></div></section>

        <section className="faq section"><div className="container"><div className="section-kicker centered">Questions, answered</div><h2>Built to earn your trust.</h2><div className="faq-list"><details open><summary>Does CreatorPulse change or upload videos?</summary><p>CreatorPulse never changes a video automatically. After you explicitly connect YouTube and confirm a save, it can update supported metadata such as title, description, and tags. It does not publish or delete content on its own.</p></details><details><summary>Are CreatorPulse scores from YouTube?</summary><p>No. They are clearly labelled derived scores calculated from your available channel data and creator-relative baselines.</p></details><details><summary>Will it work for a new channel?</summary><p>Yes, but recommendations will show Low confidence until enough history exists to support stronger conclusions.</p></details><details><summary>Does it support Shorts and long-form?</summary><p>Yes. The analysis separates formats so comparisons remain meaningful.</p></details></div></div></section>

        <section className="final-cta"><div className="container"><span>YOUR NEXT VIDEO STARTS HERE</span><h2>Know what to post next.</h2><p>Sign in, add your channel, and connect YouTube when you want live management and deeper channel analytics.</p><Link className="button light" href="/login?returnTo=/channel-setup">Analyze your channel <span>→</span></Link></div></section>
      </main>
      <MarketingFooter />
    </div>
  );
}
