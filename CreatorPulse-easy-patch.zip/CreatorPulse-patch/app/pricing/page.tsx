import { headers } from "next/headers";
import Link from "@/components/HardLink";
import { MarketingFooter } from "@/components/marketing/MarketingFooter";
import { MarketingHeader } from "@/components/marketing/MarketingHeader";
import { getAuthenticatedViewer } from "@/lib/auth/viewer";
import { getPayPalConfig } from "@/lib/billing/paypal";
import { getWorkspace } from "@/lib/workspace";

export const dynamic = "force-dynamic";

const plans = [
  { id: "free", name: "Free", price: "€0", copy: "Build a useful baseline from your own channel.", features: ["1 active channel", "Channel dashboard", "1 View Planner strategy", "Up to 28-day analytics range"] },
  { id: "pro", name: "Pro", price: "€19", copy: "Unlock the full planning and analytics workflow.", features: ["Everything in Free", "All 3 View Planner strategies", "Full Growth Plan", "Up to 365-day connected analytics"] },
] as const;

export default async function PricingPage({ searchParams }: { searchParams: Promise<{ billing?: string }> }) {
  const viewer = await getAuthenticatedViewer(await headers());
  const workspace = viewer ? await getWorkspace(viewer) : null;
  const currentPlan = workspace?.plan ?? null;
  const owner = workspace?.owner ?? false;
  const configured = Boolean(getPayPalConfig());
  const billing = (await searchParams).billing;
  const notices: Record<string, string> = { not_configured: "PayPal checkout is ready, but the server credentials and plan IDs still need to be added.", cancelled: "Checkout was cancelled. Your current plan has not changed.", failed: "PayPal could not start or verify checkout. Please try again." };
  return <div className="marketing-page"><MarketingHeader /><main>
    <section className="subpage-hero centered pricing-hero"><div className="container"><span>TRANSPARENT PRICING</span><h1>Professional creator intelligence, <em>with a clear data source.</em></h1><p>Start free. Upgrade through secure PayPal recurring billing when the extra capacity earns its place.</p><div className="trust-row"><span>✓ Cancel anytime</span><span>✓ Public analysis works without OAuth</span><span>✓ Secure PayPal approval</span></div></div></section>
    <section className="pricing-page-section"><div className="container">
      {billing && <div className="connection-notice error billing-notice"><strong>Checkout update</strong><span>{notices[billing] ?? "Your plan was not changed."}</span></div>}
      {owner && <div className="connection-notice success billing-notice"><strong>Creator+ owner access active</strong><span>Your internal owner entitlement remains active independently of the public Free and Pro plans shown below.</span></div>}
      <div className="pricing-grid">{plans.map((plan) => {
        const isCurrent = currentPlan === plan.id; const paid = plan.id !== "free";
        return <article className={plan.id === "pro" ? "featured" : ""} key={plan.id}>{plan.id === "pro" && <span className="popular">MOST POPULAR</span>}<div className="plan-name-row"><h2>{plan.name}</h2>{isCurrent && <span className="current-plan">{owner ? "Owner plan" : "Current plan"}</span>}</div><p>{plan.copy}</p><strong>{plan.price}{paid && <small>/ month</small>}</strong><ul>{plan.features.map((feature) => <li key={feature}>{feature}</li>)}</ul>
          {isCurrent ? <Link className="button secondary" href={owner ? "/dashboard" : paid ? "/settings#billing" : "/dashboard"}>{owner ? "Owner access active" : paid ? "Manage subscription" : "Open free workspace"}</Link> : !paid ? <Link className="button secondary" href={viewer ? "/dashboard" : "/login"}>Start free</Link> : !viewer ? <Link className="button" href="/login?returnTo=/pricing">Sign in to choose {plan.name}</Link> : currentPlan && currentPlan !== "free" ? <Link className="button secondary" href="/settings#billing">Manage current plan first</Link> : <form action="/api/billing/checkout" method="post"><input type="hidden" name="plan" value={plan.id} /><button className="button" type="submit" disabled={!configured}>{configured ? `Choose ${plan.name} with PayPal` : "PayPal setup required"}</button></form>}
        </article>;
      })}</div>
      <div className="pricing-assurance"><div><span>PAYMENT SECURITY</span><h2>CreatorPulse never handles your card details.</h2><p>Paid subscriptions are approved on PayPal. CreatorPulse verifies signed PayPal webhooks before granting or removing plan access.</p></div><Link href="/help">Read billing help →</Link></div>
    </div></section>
  </main><MarketingFooter /></div>;
}
