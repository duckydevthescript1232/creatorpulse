import { headers } from "next/headers";
import Link from "@/components/HardLink";
import { DashboardShell } from "@/components/app/DashboardShell";
import { VideoManager } from "@/components/app/VideoManager";
import { getAuthenticatedViewer } from "@/lib/auth/viewer";
import { getWorkspace, workspaceShell } from "@/lib/workspace";
import { youtubeWriteScope } from "@/lib/youtube/scopes";

export const dynamic = "force-dynamic";

export default async function VideosPage({ searchParams }: { searchParams: Promise<{ video?: string }> }) {
  const viewer = await getAuthenticatedViewer(await headers());
  if (!viewer) return <DashboardShell active="Videos"><section className="product-empty"><span>VIDEO MANAGER</span><h1>Sign in to manage your uploads</h1><p>Public analysis and connected YouTube metadata remain private to your CreatorPulse workspace.</p><Link className="button" href="/login?returnTo=/videos">Continue securely</Link></section></DashboardShell>;
  const [workspace, params] = await Promise.all([getWorkspace(viewer, { videoLimit: 500 }), searchParams]);
  if (!workspace.source || !workspace.videos.length) return <DashboardShell active="Videos" {...workspaceShell(workspace)}><section className="product-empty"><span>VIDEO MANAGER</span><h1>Your video library will appear here</h1><p>Analyze a public channel for read-only insights, or connect YouTube for real descriptions, tags, visibility, and safe editing.</p><Link className="button" href="/channel-setup">Add your channel</Link></section></DashboardShell>;
  const writable = workspace.source.sourceType === "oauth" && Boolean(workspace.connection?.scopes.includes(youtubeWriteScope));
  return <DashboardShell active="Videos" {...workspaceShell(workspace)}>
    <div className={`source-ribbon ${writable ? "" : "read-only"}`}><div><strong>{writable ? "Connected YouTube workspace" : "Read-only public analysis"}</strong><span>{writable ? "Real metadata loaded server-side. Changes publish only after explicit confirmation." : "Titles and public statistics are real; private descriptions and tags are marked unavailable."}</span></div><Link href="/settings">{writable ? "Connection settings" : "Connect YouTube to edit"}</Link></div>
    <VideoManager videos={workspace.videos} initialVideoId={params.video} writable={writable} totalUploadCount={workspace.snapshot?.uploads ?? workspace.source.publicUploadCount ?? workspace.videos.length} />
  </DashboardShell>;
}
