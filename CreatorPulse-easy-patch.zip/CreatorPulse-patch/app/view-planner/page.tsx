import { headers } from "next/headers";
import Link from "@/components/HardLink";
import { ConfidenceBadge } from "@/components/app/ConfidenceBadge";
import { DashboardShell } from "@/components/app/DashboardShell";
import { getAuthenticatedViewer } from "@/lib/auth/viewer";
import { compactNumber } from "@/lib/insights/channel";
import { createViewPlan, type ViewStrategy } from "@/lib/insights/view-planner";
import { planEntitlements } from "@/lib/entitlements/plans";
import { getWorkspace, workspaceShell } from "@/lib/workspace";
import { listPlannerItems } from "@/lib/planner/repository";
import { PlannerBoard } from "@/components/app/PlannerBoard";

export const dynamic = "force-dynamic";

const strategies: Array<{ id: ViewStrategy; label: string; copy: string }> = [
  { id: "repeat", label: "Repeat a winner", copy: "Keep the proven audience promise and create a distinct follow-up." },
  { id: "expand", label: "Expand the format", copy: "Move the strongest topic into a complementary format." },
  { id: "reset", label: "Reset the packaging", copy: "Keep the useful topic but make the payoff clearer." },
];

export default async function ViewPlannerPage({ searchParams }: { searchParams: Promise<{ strategy?: string }> }) {
  const viewer = await getAuthenticatedViewer(await headers());
  if (!viewer) return <DashboardShell active="View Planner"><section className="product-empty"><span>VIEW PLANNER</span><h1>Sign in to build your no-credit view plan</h1><p>The planner turns your own upload history into a practical publishing experiment—without an AI API.</p><Link className="button" href="/login?returnTo=/view-planner">Continue securely</Link></section></DashboardShell>;
  const workspace = await getWorkspace(viewer); const requested = (await searchParams).strategy; const strategyCount = planEntitlements[workspace.plan].viewPlannerStrategies; const requestedStrategy: ViewStrategy = requested === "expand" || requested === "reset" ? requested : "repeat"; const strategy: ViewStrategy = strategyCount === 1 ? "repeat" : requestedStrategy; const plan = createViewPlan(workspace.videos, strategy); const plannedItems = workspace.source ? await listPlannerItems(viewer.id, workspace.source.channelId) : [];
  if (!workspace.source || !plan) return <DashboardShell active="View Planner" {...workspaceShell(workspace)}><section className="product-empty"><span>VIEW PLANNER</span><h1>Your first view plan needs channel evidence</h1><p>Analyze a public channel with recent uploads. No Google connection or paid AI credits are required.</p><Link className="button" href="/channel-setup">Analyze your channel</Link></section></DashboardShell>;
  return <DashboardShell active="View Planner" {...workspaceShell(workspace)}>
    <div className="source-ribbon"><div><strong>Zero-credit View Planner</strong><span>Built from your channel baselines—not generated claims or paid AI calls.</span></div><span className="status-pill"><i />Ready now</span></div>
    <section className="inner-page-heading"><div><span className="eyebrow">Weekly view plan</span><h1>Turn one proven signal into your next experiment.</h1><p>Choose a route, package it clearly, and measure it against comparable uploads.</p></div><ConfidenceBadge level={plan.confidence} /></section>
    <nav className="planner-strategies" aria-label="View strategy">{strategies.map((item, index) => { const locked = index >= strategyCount; return <Link className={`${strategy === item.id ? "active" : ""}${locked ? " locked" : ""}`} href={locked ? "/pricing" : `/view-planner?strategy=${item.id}`} key={item.id}><strong>{item.label}{locked ? " · Pro" : ""}</strong><span>{item.copy}</span></Link>; })}</nav>
    <article className="planner-focus"><div className="planner-focus-copy"><span>THIS WEEK’S VIEW OPPORTUNITY</span><h2>{plan.strategyLabel}: {plan.topic}</h2><p>“{plan.winner.title}” reached <strong>{plan.ratio.toFixed(1)}×</strong> your comparable upload baseline. The plan keeps its audience promise while changing the creative execution.</p><div className="planner-specs"><div><span>Format</span><strong>{plan.targetFormat}</strong></div><div><span>Target length</span><strong>{plan.durationTarget}</strong></div><div><span>Success baseline</span><strong>{compactNumber(plan.baselineViews)} views</strong></div></div></div><aside><span>OPENING RULE</span><strong>{plan.hook}</strong><small>Based on the selected format, not a claimed YouTube guarantee.</small></aside></article>
    <section className="planner-packaging"><div className="card-heading"><div><span>Packaging workshop</span><h2>Three directions to write in your own voice</h2></div></div><div>{plan.titles.map((title, index) => <article key={title}><span>0{index + 1}</span><h3>{title}</h3><p>{index === 0 ? "Closest follow-up to the proven signal." : index === 1 ? "A more personal, outcome-led variation." : "A curiosity-led alternative for a clean test."}</p></article>)}</div></section>
    <section className="planner-week"><div className="card-heading"><div><span>Execution plan</span><h2>Five actions from evidence to review</h2></div><Link href="/videos">Inspect the winning upload →</Link></div>{plan.steps.map((step) => <article key={step.day}><span>{step.day}</span><b>{step.label}</b><div><h3>{step.title}</h3><p>{step.copy}</p></div></article>)}</section>
    <section className="planner-guardrail"><strong>What this plan does not claim</strong><p>It does not know future views, hidden recommendation signals, or the best posting time. It gives you a controlled experiment based on your own visible history so the next result teaches you something useful.</p><Link href="/analytics">Review the evidence →</Link></section>
    <PlannerBoard initialItems={plannedItems} />
  </DashboardShell>;
}
