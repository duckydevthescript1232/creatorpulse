import NextLink from "next/link";
import type { AnchorHTMLAttributes } from "react";

type HardLinkProps = Omit<AnchorHTMLAttributes<HTMLAnchorElement>, "href"> & { href: string; prefetch?: boolean };

export default function HardLink({ href, children, prefetch, ...props }: HardLinkProps) {
  const native = href.startsWith("http://") || href.startsWith("https://") || href.startsWith("mailto:") || href.startsWith("/api/");
  return native ? <a href={href} {...props}>{children}</a> : <NextLink href={href} prefetch={prefetch} {...props}>{children}</NextLink>;
}
