"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import type { CreatorPlanProfile, CreatorPlanProfileInput } from "@/lib/planning/profile";

const goalLabels = { views: "More views", subscribers: "More subscribers", consistency: "Post consistently", monetization: "Build toward monetization" } as const;
const challengeLabels = { ideation: "Finding ideas", consistency: "Staying consistent", hooks: "Stronger hooks", retention: "Keeping viewers", packaging: "Titles and thumbnails" } as const;
const allFormats = ["Short", "Long-form", "Stream"] as const;
const emptyProfile: CreatorPlanProfileInput = { primaryGoal: "views", niche: "", targetAudience: "", preferredFormats: ["Short"], weeklyUploads: 3, weeklyHours: 6, biggestChallenge: "ideation" };

export function CreatorPlanQuestionnaire({ initialProfile }: { initialProfile: CreatorPlanProfile | null }) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const [answers, setAnswers] = useState<CreatorPlanProfileInput>(initialProfile ?? emptyProfile);
  const [editing, setEditing] = useState(!initialProfile);
  const [status, setStatus] = useState<"idle" | "saving" | "saved">("idle");
  const [error, setError] = useState("");

  function toggleFormat(format: CreatorPlanProfileInput["preferredFormats"][number]) {
    setAnswers((current) => ({ ...current, preferredFormats: current.preferredFormats.includes(format) ? current.preferredFormats.filter((item) => item !== format) : [...current.preferredFormats, format] }));
  }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("saving");
    setError("");
    try {
      const response = await fetch("/api/plan-profile", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(answers) });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw new Error(result.error ?? "Could not save your answers.");
      setStatus("saved");
      setEditing(false);
      startTransition(() => router.refresh());
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not save your answers.");
      setStatus("idle");
    }
  }

  if (!editing) return <section className="plan-profile-summary"><div><span>YOUR CREATOR BRIEF</span><h2>{goalLabels[answers.primaryGoal]} in {answers.niche}</h2><p>{answers.weeklyUploads} upload{answers.weeklyUploads === 1 ? "" : "s"} per week · {answers.weeklyHours} hours available · Focus: {challengeLabels[answers.biggestChallenge]}</p></div><button type="button" onClick={() => { setEditing(true); setStatus("idle"); }}>Edit answers</button></section>;

  return <form className="plan-questionnaire" onSubmit={save}><header><div><span>PERSONALIZE YOUR PLAN</span><h2>Answer 7 quick questions.</h2><p>Your answers are saved privately and combined with real channel evidence. They never create fake YouTube analytics.</p></div><b>About 2 minutes</b></header><div className="plan-question-grid">
    <label><span>1. What is your main goal?</span><select value={answers.primaryGoal} onChange={(event) => setAnswers({ ...answers, primaryGoal: event.target.value as CreatorPlanProfileInput["primaryGoal"] })}>{Object.entries(goalLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
    <label><span>2. What is your channel niche?</span><input required minLength={2} maxLength={80} placeholder="Gaming, fitness, finance..." value={answers.niche} onChange={(event) => setAnswers({ ...answers, niche: event.target.value })} /></label>
    <label className="wide"><span>3. Who do you want to reach?</span><input required minLength={2} maxLength={140} placeholder="New Roblox players who enjoy scary stories" value={answers.targetAudience} onChange={(event) => setAnswers({ ...answers, targetAudience: event.target.value })} /></label>
    <fieldset className="wide"><legend>4. Which formats do you want to make?</legend><div className="plan-format-options">{allFormats.map((format) => <button aria-pressed={answers.preferredFormats.includes(format)} className={answers.preferredFormats.includes(format) ? "selected" : ""} key={format} onClick={() => toggleFormat(format)} type="button">{format}</button>)}</div></fieldset>
    <label><span>5. Uploads you can sustain per week</span><input type="number" min={1} max={14} value={answers.weeklyUploads} onChange={(event) => setAnswers({ ...answers, weeklyUploads: Number(event.target.value) })} /></label>
    <label><span>6. Hours available per week</span><input type="number" min={1} max={60} value={answers.weeklyHours} onChange={(event) => setAnswers({ ...answers, weeklyHours: Number(event.target.value) })} /></label>
    <label className="wide"><span>7. What is your biggest challenge?</span><select value={answers.biggestChallenge} onChange={(event) => setAnswers({ ...answers, biggestChallenge: event.target.value as CreatorPlanProfileInput["biggestChallenge"] })}>{Object.entries(challengeLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
  </div>{error ? <p className="plan-form-error" role="alert">{error}</p> : null}<footer><span>Saved to your CreatorPulse account.</span><button className="button" disabled={status === "saving" || !answers.preferredFormats.length} type="submit">{status === "saving" ? "Saving plan..." : status === "saved" ? "Plan saved" : "Build my plan"}</button></footer></form>;
}
