"use client";
/* eslint-disable @next/next/no-img-element */
import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import Link from "@/components/HardLink";
import { Logo } from "@/components/brand/Logo";
import { SyncButton } from "@/components/app/SyncButton";

const PersistentShellContext = createContext(false);

const workspaceNav = [
  ["Overview", "/dashboard", "OV"],
  ["Launch Lab", "/channel-launch", "LL"],
  ["Growth Plan", "/growth-plan", "GP"],
  ["View Planner", "/view-planner", "VP"],
  ["Ideas", "/ideas", "ID"],
  ["Videos", "/videos", "VD"],
  ["Analytics", "/analytics", "AN"],
] as const;

const accountNav = [
  ["Plans & Billing", "/pricing", "PL"],
  ["Settings", "/settings", "ST"],
  ["Help", "/help", "HP"],
] as const;

type DashboardShellProps = {
  children: React.ReactNode;
  active: string;
  persistent?: boolean;
  channel?: { name: string; label: string; avatarUrl?: string | null; connected?: boolean; hasSource?: boolean; syncLabel?: string };
  viewer?: { name: string; label: string; signedIn?: boolean; role?: "ADMIN" | "USER" };
};

function initials(value: string): string { return value.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]?.toUpperCase()).join("") || "CP"; }

function labelForPath(pathname: string, fallback: string): string {
  const all = [...workspaceNav, ...accountNav] as ReadonlyArray<readonly [string, string, string]>;
  if (pathname === "/admin") return "Admin";
  return all.find(([, href]) => pathname === href || pathname.startsWith(`${href}/`))?.[0] ?? fallback;
}

export function RouteSkeleton({ label }: { label: string }) {
  return <section className="route-skeleton" aria-label={`Loading ${label}`} aria-live="polite"><header><div><span className="eyebrow violet">CreatorPulse workspace</span><h1>{label}</h1><p>The page is ready. Loading the latest workspace data…</p></div><span className="route-loading-chip"><i />Updating</span></header><div className="route-skeleton-metrics">{[0,1,2,3].map((item) => <article key={item}><span /><strong /><small /></article>)}</div><div className="route-skeleton-panel"><span /><span /><span /><span /></div></section>;
}

export function DashboardShell({ children, active, persistent = false, channel = { name: "CreatorPulse", label: "No channel selected", connected: false, hasSource: false }, viewer = { name: "Visitor", label: "Sign in to save a workspace", signedIn: false, role: "USER" } }: DashboardShellProps) {
  const nested = useContext(PersistentShellContext);
  const pathname = usePathname();
  const router = useRouter();
  const currentLabel = labelForPath(pathname, active);
  const [pendingRoute, setPendingRoute] = useState<{ label: string; href: string } | null>(null);
  const pending = pendingRoute && pathname !== pendingRoute.href.split("?", 1)[0] ? pendingRoute : null;
  const selected = pending?.label ?? currentLabel;
  const visibleAccountNav = useMemo(() => viewer.role === "ADMIN" ? [...accountNav, ["Admin", "/admin", "AD"] as const] : accountNav, [viewer.role]);

  useEffect(() => {
    if (!pendingRoute || pathname === pendingRoute.href.split("?", 1)[0]) return;
    const recovery = window.setTimeout(() => setPendingRoute(null), 5000);
    return () => window.clearTimeout(recovery);
  }, [pathname, pendingRoute]);

  if (nested && !persistent) return <>{children}</>;

  function prepare(label: string, href: string) {
    router.prefetch(href);
    const targetPath = href.split("?", 1)[0];
    if (pathname !== targetPath) setPendingRoute({ label, href });
  }

  const accountAction = viewer.signedIn
    ? <form action="/api/auth/logout" method="post"><button className="sidebar-form-link" type="submit"><span className="nav-icon">OUT</span>Log out</button></form>
    : <Link href="/login?returnTo=/dashboard"><span className="nav-icon">IN</span>Sign in</Link>;

  return <PersistentShellContext.Provider value={true}><div className="app-shell">
    <aside className="sidebar">
      <div className="sidebar-logo"><Logo /></div><span className="nav-label">WORKSPACE</span>
      <nav aria-label="CreatorPulse navigation">{workspaceNav.map(([label, href, icon]) => <Link aria-current={selected === label ? "page" : undefined} className={selected === label ? "active" : ""} href={href} key={href} onClick={() => prepare(label, href)} onFocus={() => router.prefetch(href)} onMouseEnter={() => router.prefetch(href)}><span className="nav-icon">{icon}</span>{label}</Link>)}</nav>
      <div className="sidebar-bottom"><span className="nav-label">ACCOUNT</span>{visibleAccountNav.map(([label, href, icon]) => <Link aria-current={selected === label ? "page" : undefined} className={selected === label || (label === "Plans & Billing" && selected === "Pricing") ? "active" : ""} href={href} key={href} onClick={() => prepare(label, href)} onFocus={() => router.prefetch(href)} onMouseEnter={() => router.prefetch(href)}><span className="nav-icon">{icon}</span>{label}</Link>)}{accountAction}<div className="profile-row"><span className="avatar">{initials(viewer.name)}</span><div><strong>{viewer.name}{viewer.role === "ADMIN" && <b className="mini-admin-badge">ADMIN</b>}</strong><small>{viewer.label}</small></div></div></div>
    </aside>

    <div className="app-main"><header className="app-topbar">
      <details className="mobile-menu"><summary aria-label="Open navigation"><span /><span /><span /></summary><nav aria-label="Mobile navigation">{[...workspaceNav, ...visibleAccountNav].map(([label, href]) => <Link href={href} key={href} onClick={() => prepare(label, href)}>{label}</Link>)}</nav></details>
      <div className="mobile-brand"><Logo compact /></div>
      <details className="channel-menu"><summary className="channel-switcher">{channel.avatarUrl ? <img src={channel.avatarUrl} alt="" /> : <span className="avatar small">{initials(channel.name)}</span>}<span><strong>{channel.name}</strong><small>{channel.label}</small></span><b aria-hidden="true">⌄</b></summary><div><strong>{channel.connected ? "YouTube connected" : channel.hasSource ? "Public channel analysis" : "No channel yet"}</strong><span>{channel.syncLabel ?? "Start with a public YouTube @handle—no API key required."}</span><Link href={channel.hasSource ? "/settings" : "/channel-setup"}>{channel.hasSource ? "Manage channel data" : "Add a channel"}</Link></div></details>
      <div className="topbar-context"><span>Workspace</span><strong>{pending?.label ?? selected}</strong></div>
      <div className="topbar-actions">{channel.connected ? <SyncButton enabled /> : <Link className="topbar-sync" href="/channel-setup" onClick={() => prepare("Channel setup", "/channel-setup")}><span aria-hidden="true">{channel.hasSource ? "SCAN" : "ADD"}</span>{channel.hasSource ? "Refresh channel" : "Add channel"}</Link>}<details className="notification-menu"><summary aria-label="Open data status">Data status</summary><div><strong>Workspace data status</strong><p>{channel.hasSource ? "Recommendations use your latest available channel evidence." : "Analyze a channel to activate recommendations."}</p><Link href={channel.hasSource ? "/settings" : "/channel-setup"}>{channel.hasSource ? "Review data sources" : "Add channel data"}</Link></div></details><details className="account-menu"><summary aria-label="Open account menu"><span className="avatar">{initials(viewer.name)}</span><b>⌄</b></summary><div><strong>{viewer.name}</strong>{viewer.role === "ADMIN" && <span className="admin-badge">ADMIN</span>}<span>{viewer.label}</span>{viewer.signedIn ? <><Link href="/settings">Account settings</Link>{viewer.role === "ADMIN" && <Link href="/admin">Admin console</Link>}<form action="/api/auth/logout" method="post"><button type="submit">Log out</button></form></> : <Link href="/login?returnTo=/dashboard">Sign in securely</Link>}</div></details></div>
    </header><main className="dashboard-content" aria-busy={Boolean(pending)}>{pending ? <><div className="route-progress" role="status"><i /><span>Opening {pending.label}</span></div><RouteSkeleton label={pending.label} /></> : children}</main></div>
  </div></PersistentShellContext.Provider>;
}
