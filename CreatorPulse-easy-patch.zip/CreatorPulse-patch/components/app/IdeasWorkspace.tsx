"use client";

import { useState } from "react";
import type { Confidence, VideoFormat } from "@/lib/domain/types";

type Idea = { title: string; format: VideoFormat; score: number; rationale: string; confidence: Confidence };

export function IdeasWorkspace({ ideas }: { ideas: Idea[] }) {
  const [added, setAdded] = useState<string[]>([]);
  const [pending, setPending] = useState<string[]>([]);
  const [notice, setNotice] = useState("");

  async function add(idea: Idea) {
    if (added.includes(idea.title) || pending.includes(idea.title)) return;
    setPending((current) => [...current, idea.title]);
    setNotice("Saving idea to View Planner...");
    const topic = idea.title.replace(/^\d+\s+/, "").split(/\s+/).slice(0, 4).join(" ");
    try {
      const response = await fetch("/api/planner", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ workingTitle: idea.title, topic, format: idea.format, notes: idea.rationale, tags: [] }) });
      const body = await response.json().catch(() => ({})) as { error?: string };
      if (!response.ok) throw new Error(body.error ?? "Could not add this idea.");
      setAdded((current) => current.includes(idea.title) ? current : [...current, idea.title]);
      setNotice("Added to View Planner");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Could not add this idea. You can retry safely.");
    } finally {
      setPending((current) => current.filter((title) => title !== idea.title));
    }
  }

  return <>
    <div className="ideas-workspace">{ideas.map((idea, index) => {
      const isAdded = added.includes(idea.title);
      const isPending = pending.includes(idea.title);
      return <article key={idea.title}><div className="idea-priority"><span>0{index + 1}</span><strong>{idea.score}</strong><small>Opportunity</small></div><div className="idea-content"><div><span className="status-pill neutral">{idea.format}</span><span className={`confidence-dot ${idea.confidence.toLowerCase()}`}>{idea.confidence} confidence</span></div><h2>{idea.title}</h2><p>{idea.rationale}</p><dl><div><dt>Hook</dt><dd>Open with the outcome, tension, or constraint before the setup.</dd></div><div><dt>Why it fits</dt><dd>Grounded in repeated topics, format performance, or a strong upload from your own channel.</dd></div></dl></div><button type="button" className="button secondary" onClick={() => void add(idea)} disabled={isAdded || isPending}>{isPending ? "Adding..." : isAdded ? "Added to Planner" : "Add to Planner"}</button></article>;
    })}</div>
    {notice && <div className="floating-toast" role="status"><strong>{notice}</strong><span>{notice === "Added to View Planner" ? "The idea is now saved in your production pipeline." : "CreatorPulse keeps the current page usable while this action completes."}</span></div>}
  </>;
}
