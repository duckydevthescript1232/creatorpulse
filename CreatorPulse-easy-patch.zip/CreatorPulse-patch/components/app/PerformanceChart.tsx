"use client";

import { useMemo, useState } from "react";

type Point = { date: string; value: number; label: string };

type PerformanceChartProps = {
  points: Point[];
  anchorDate: string;
  title?: string;
  description?: string;
  fixedDays?: number;
  emptyMessage?: string;
  ariaLabel?: string;
};

function downsample(points: Point[], maxPoints = 30): Point[] {
  if (points.length <= maxPoints) return points;
  const bucketSize = points.length / maxPoints;
  const output: Point[] = [];
  for (let bucket = 0; bucket < maxPoints; bucket += 1) {
    const start = Math.floor(bucket * bucketSize);
    const end = Math.max(start + 1, Math.floor((bucket + 1) * bucketSize));
    const slice = points.slice(start, end);
    if (!slice.length) continue;
    const value = slice.reduce((sum, point) => sum + point.value, 0);
    const representative = slice[Math.floor(slice.length / 2)];
    output.push({ ...representative, value, label: representative.label });
  }
  return output;
}

export function PerformanceChart({
  points,
  anchorDate,
  title = "Views by published upload",
  description = "Real sampled video views, plotted by publish date.",
  fixedDays,
  emptyMessage = "Not enough data in this period. Choose a longer range.",
  ariaLabel,
}: PerformanceChartProps) {
  const [interactiveDays, setInteractiveDays] = useState(28);
  const days = fixedDays ?? interactiveDays;
  const series = useMemo(() => {
    const anchor = Date.parse(anchorDate);
    const cutoff = Number.isFinite(anchor) ? anchor - Math.max(0, days - 1) * 86_400_000 : Number.NEGATIVE_INFINITY;
    const filtered = points
      .filter((point) => Number.isFinite(Date.parse(point.date)) && Date.parse(point.date) >= cutoff)
      .sort((a, b) => Date.parse(a.date) - Date.parse(b.date));
    return downsample(filtered, 30);
  }, [anchorDate, days, points]);
  const max = Math.max(1, ...series.map((point) => point.value));

  return <article className="performance-chart">
    <header>
      <div><span>RECENT PERFORMANCE</span><h2>{title}</h2><p>{description}</p></div>
      {fixedDays === undefined && <div className="chart-periods">{[7, 28, 90, 365].map((value) => <button type="button" aria-pressed={days === value} className={days === value ? "active" : ""} onClick={() => setInteractiveDays(value)} key={value}>{value}D</button>)}</div>}
    </header>
    {series.length >= 2 ? <div className="line-chart" role="img" aria-label={ariaLabel ?? `${title} for ${series.length} points in the last ${days} days`}>
      <div className="chart-grid-lines"><i /><i /><i /><i /></div>
      {series.map((point, index) => {
        const x = series.length === 1 ? 50 : index / (series.length - 1) * 100;
        const y = 92 - point.value / max * 76;
        const next = series[index + 1];
        const nextX = next ? (index + 1) / (series.length - 1) * 100 : x;
        const nextY = next ? 92 - next.value / max * 76 : y;
        const dx = nextX - x;
        const dy = nextY - y;
        const length = Math.sqrt(dx * dx + dy * dy);
        const angle = Math.atan2(dy, dx) * 180 / Math.PI;
        return <div key={`${point.date}-${point.label}-${index}`}>
          <span className="chart-point" style={{ left: `${x}%`, top: `${y}%` }}><b>{new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 }).format(point.value)}</b><small>{point.label}<br />{new Date(point.date).toLocaleDateString("en-US")}</small></span>
          {next && <i className="chart-segment" style={{ left: `${x}%`, top: `${y}%`, width: `${length}%`, transform: `rotate(${angle}deg)` }} />}
        </div>;
      })}
      <div className="chart-axis"><span>{new Date(series[0].date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span><span>{new Date(series.at(-1)!.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span></div>
    </div> : <div className="chart-empty">{emptyMessage}</div>}
  </article>;
}
