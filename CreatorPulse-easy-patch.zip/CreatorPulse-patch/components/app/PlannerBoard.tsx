"use client";

import { useState } from "react";
import type { PlannerItem, PlannerStatus, VideoFormat } from "@/lib/domain/types";

const statusLabels: Record<PlannerStatus, string> = {
  idea: "Idea",
  planned: "Planned",
  recording: "Recording",
  published: "Published",
};
const goals = ["Reach more viewers", "Gain subscribers", "Improve retention", "Publish consistently"] as const;
type NewItem = {
  goal: string;
  audience: string;
  workingTitle: string;
  topic: string;
  format: VideoFormat;
  targetDate: string;
  viewerPromise: string;
  constraint: string;
  tags: string;
  thumbnailIdea: string;
};
const emptyItem: NewItem = {
  goal: "",
  audience: "",
  workingTitle: "",
  topic: "",
  format: "Long-form",
  targetDate: "",
  viewerPromise: "",
  constraint: "",
  tags: "",
  thumbnailIdea: "",
};

function planningScore(item: Pick<PlannerItem, "workingTitle" | "topic" | "tags" | "thumbnailIdea" | "targetDate">) {
  return Math.min(100, 35 + (item.workingTitle.length >= 30 ? 20 : 8) + (item.topic ? 15 : 0) + (item.tags.length >= 3 ? 15 : item.tags.length * 3) + (item.thumbnailIdea ? 10 : 0) + (item.targetDate ? 5 : 0));
}

export function PlannerBoard({ initialItems }: { initialItems: PlannerItem[] }) {
  const [items, setItems] = useState(initialItems);
  const [form, setForm] = useState<NewItem>(emptyItem);
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [notice, setNotice] = useState("");
  const [saving, setSaving] = useState(false);
  const [dragged, setDragged] = useState<string | null>(null);
  const stepReady = step === 1
    ? Boolean(form.goal && form.audience.trim())
    : step === 2
      ? Boolean(form.topic.trim() && form.workingTitle.trim())
      : Boolean(form.viewerPromise.trim());

  function openQuestionnaire() {
    setOpen(true);
    setStep(1);
    setNotice("");
  }

  async function create() {
    setSaving(true);
    setNotice("");
    const notes = [
      `Goal: ${form.goal}`,
      `Audience: ${form.audience}`,
      `Viewer promise: ${form.viewerPromise}`,
      form.constraint ? `Production constraint: ${form.constraint}` : "",
    ].filter(Boolean).join("\n").slice(0, 1000);
    try {
      const response = await fetch("/api/planner", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          workingTitle: form.workingTitle,
          topic: form.topic,
          format: form.format,
          targetDate: form.targetDate || null,
          notes,
          tags: form.tags.split(",").map((tag) => tag.trim()).filter(Boolean),
          thumbnailIdea: form.thumbnailIdea,
        }),
      });
      const body = await response.json() as { item?: PlannerItem; error?: string };
      if (!response.ok || !body.item) throw new Error(body.error ?? "Could not add this plan.");
      setItems((current) => [...current, body.item!]);
      setForm(emptyItem);
      setStep(1);
      setOpen(false);
      setNotice("Plan created — your answers are saved in the production brief.");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Could not add this plan.");
    } finally {
      setSaving(false);
    }
  }

  async function patch(id: string, changes: Partial<PlannerItem>) {
    let previous: PlannerItem[] = [];
    setItems((current) => { previous = current; return current.map((item) => item.id === id ? { ...item, ...changes } : item); });
    try {
      const response = await fetch(`/api/planner/${id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(changes) });
      if (!response.ok) throw new Error();
      setNotice("");
    } catch {
      setItems(previous);
      setNotice("Could not update this plan. Your previous state was restored.");
    }
  }

  async function remove(id: string) {
    const previous = items;
    setItems((current) => current.filter((item) => item.id !== id));
    try {
      const response = await fetch(`/api/planner/${id}`, { method: "DELETE" });
      if (!response.ok) throw new Error();
      setNotice("");
    } catch {
      setItems(previous);
      setNotice("Could not remove this plan. The previous item was restored.");
    }
  }

  function drop(targetId: string) {
    if (!dragged || dragged === targetId) return;
    const previous = items;
    const reordered = [...items];
    const from = reordered.findIndex((item) => item.id === dragged);
    const to = reordered.findIndex((item) => item.id === targetId);
    if (from < 0 || to < 0) { setDragged(null); return; }
    const [item] = reordered.splice(from, 1);
    if (!item) { setDragged(null); return; }
    reordered.splice(to, 0, item);
    const positioned = reordered.map((value, position) => ({ ...value, position }));
    setItems(positioned);
    setDragged(null);
    void fetch("/api/planner/reorder", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ids: positioned.map((value) => value.id) }),
    }).then((response) => {
      if (!response.ok) {
        setItems(previous);
        setNotice("Could not reorder this plan. The previous order was restored.");
      }
    });
  }

  return (
    <section className="planner-board-section">
      <header>
        <div>
          <span>UPCOMING CONTENT</span>
          <h2>Your production pipeline</h2>
          <p>Answer a short creator brief, then move each evidence-backed concept toward publication.</p>
        </div>
        <button type="button" className="button" aria-expanded={open} aria-controls="plan-questionnaire" onClick={() => open ? setOpen(false) : openQuestionnaire()}>
          {open ? "Close questions" : "Build my plan"}
        </button>
      </header>
      {notice && <div className="inline-notice" role="status">{notice}</div>}

      {open && (
        <div className="plan-questionnaire" id="plan-questionnaire">
          <div className="questionnaire-progress" aria-label={`Questionnaire step ${step} of 3`}>
            <div><span>PLAN BRIEF</span><strong>Step {step} of 3</strong></div>
            <i><b style={{ width: `${step / 3 * 100}%` }} /></i>
          </div>
          <div className="questionnaire-step" key={step}>
            {step === 1 ? (
              <>
                <span className="question-number">01 · DIRECTION</span>
                <h3>What should this video achieve?</h3>
                <p>CreatorPulse uses this answer to keep the plan focused on one measurable outcome.</p>
                <div className="answer-choices">
                  {goals.map((goal) => (
                    <button type="button" className={form.goal === goal ? "selected" : ""} onClick={() => setForm({ ...form, goal })} key={goal}>
                      <i />{goal}
                    </button>
                  ))}
                </div>
                <label>
                  <span>Who is the exact viewer you want to help or entertain?</span>
                  <input maxLength={240} value={form.audience} onChange={(event) => setForm({ ...form, audience: event.target.value })} placeholder="Example: Roblox players who enjoy difficult challenge videos" />
                </label>
              </>
            ) : step === 2 ? (
              <>
                <span className="question-number">02 · CONCEPT</span>
                <h3>What are you making for them?</h3>
                <p>Use a working title—the plan stays editable and nothing is published automatically.</p>
                <div className="question-grid">
                  <label>
                    <span>What topic will the video cover?</span>
                    <input maxLength={60} value={form.topic} onChange={(event) => setForm({ ...form, topic: event.target.value })} placeholder="Main topic or recurring series" />
                  </label>
                  <label>
                    <span>What is the current working title?</span>
                    <input maxLength={100} value={form.workingTitle} onChange={(event) => setForm({ ...form, workingTitle: event.target.value })} placeholder="A clear audience promise" />
                    <small>{form.workingTitle.length} / 100 characters</small>
                  </label>
                </div>
                <fieldset>
                  <legend>Which content format fits this idea?</legend>
                  <div className="answer-choices format-choices">
                    {(["Long-form", "Short", "Stream"] as VideoFormat[]).map((format) => (
                      <button type="button" className={form.format === format ? "selected" : ""} onClick={() => setForm({ ...form, format })} key={format}>
                        <i />{format}
                      </button>
                    ))}
                  </div>
                </fieldset>
              </>
            ) : (
              <>
                <span className="question-number">03 · EXECUTION</span>
                <h3>What must viewers get from the video?</h3>
                <p>This becomes the production brief you can return to while scripting and recording.</p>
                <label>
                  <span>Finish this sentence: “By the end, the viewer will...”</span>
                  <textarea maxLength={400} value={form.viewerPromise} onChange={(event) => setForm({ ...form, viewerPromise: event.target.value })} placeholder="Understand, feel, discover, or see a specific payoff" />
                </label>
                <div className="question-grid">
                  <label><span>When do you want to publish?</span><input type="date" value={form.targetDate} onChange={(event) => setForm({ ...form, targetDate: event.target.value })} /></label>
                  <label><span>What production constraint should the plan respect?</span><input maxLength={240} value={form.constraint} onChange={(event) => setForm({ ...form, constraint: event.target.value })} placeholder="Time, budget, equipment, or length" /></label>
                  <label><span>Which keywords genuinely describe it?</span><input maxLength={300} value={form.tags} onChange={(event) => setForm({ ...form, tags: event.target.value })} placeholder="roblox, challenge, keyboard" /></label>
                  <label><span>What is the thumbnail&apos;s single visual idea?</span><input maxLength={300} value={form.thumbnailIdea} onChange={(event) => setForm({ ...form, thumbnailIdea: event.target.value })} placeholder="One subject, emotion, or tension point" /></label>
                </div>
              </>
            )}
          </div>
          <footer className="questionnaire-actions">
            <button type="button" className="button secondary" onClick={() => step === 1 ? setOpen(false) : setStep(step - 1)}>{step === 1 ? "Cancel" : "Back"}</button>
            <span>{stepReady ? "Ready to continue" : "Answer the required question to continue"}</span>
            {step < 3
              ? <button type="button" className="button" onClick={() => setStep(step + 1)} disabled={!stepReady}>Continue</button>
              : <button type="button" className="button" onClick={create} disabled={saving || !stepReady}>{saving ? "Creating plan..." : "Create my plan"}</button>}
          </footer>
        </div>
      )}

      {items.length ? (
        <div className="planner-board">
          {items.map((item) => (
            <article draggable onDragStart={() => setDragged(item.id)} onDragOver={(event) => event.preventDefault()} onDrop={() => drop(item.id)} key={item.id}>
              <div className="drag-handle" title="Drag to reorder">::</div>
              <div className="plan-card-main">
                <div><span>{item.format}</span><b>{statusLabels[item.status]}</b></div>
                <h3>{item.workingTitle}</h3>
                <p>{item.notes || `A planned ${item.format.toLowerCase()} video about ${item.topic}.`}</p>
                <div className="plan-tags">
                  {item.tags.map((tag) => <span key={tag}>{tag}</span>)}
                  {item.thumbnailIdea && <span>Thumbnail: {item.thumbnailIdea}</span>}
                </div>
              </div>
              <div className="plan-card-meta">
                <strong>{planningScore(item)}</strong><span>Plan readiness</span>
                <small>{item.targetDate ? new Date(`${item.targetDate}T12:00:00Z`).toLocaleDateString("en-US") : "No target date"}</small>
                <select aria-label={`Status for ${item.workingTitle}`} value={item.status} onChange={(event) => patch(item.id, { status: event.target.value as PlannerStatus })}>
                  {Object.entries(statusLabels).map(([value, label]) => <option value={value} key={value}>{label}</option>)}
                </select>
                <button type="button" onClick={() => remove(item.id)}>Remove</button>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="planner-empty">
          <strong>No upcoming videos yet</strong>
          <p>Answer seven focused questions to create a useful production brief—not a generic idea card.</p>
          <button type="button" className="button secondary" onClick={openQuestionnaire}>Answer the planning questions</button>
        </div>
      )}
    </section>
  );
}
