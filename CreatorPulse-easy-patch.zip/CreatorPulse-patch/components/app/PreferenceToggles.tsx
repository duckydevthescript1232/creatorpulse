"use client";

import { useEffect, useState } from "react";

type Preferences = { compact: boolean; reduceMotion: boolean };
const defaults: Preferences = { compact: false, reduceMotion: false };

function applyPreferences(preferences: Preferences) {
  document.documentElement.dataset.density = preferences.compact ? "compact" : "comfortable";
  document.documentElement.dataset.motion = preferences.reduceMotion ? "reduced" : "full";
}

export function PreferenceToggles() {
  const [preferences, setPreferences] = useState(defaults);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      const stored: Preferences = {
        compact: localStorage.getItem("creatorpulse-compact") === "true",
        reduceMotion: localStorage.getItem("creatorpulse-reduce-motion") === "true",
      };
      setPreferences(stored);
      applyPreferences(stored);
      setReady(true);
    });
    return () => window.cancelAnimationFrame(frame);
  }, []);

  function update(next: Preferences) {
    setPreferences(next);
    localStorage.setItem("creatorpulse-compact", String(next.compact));
    localStorage.setItem("creatorpulse-reduce-motion", String(next.reduceMotion));
    applyPreferences(next);
  }

  return <div className="preference-list" aria-busy={!ready}>
    <div><span><strong>Compact density</strong><small>Show more information on large screens. This preference persists on this device.</small></span><input aria-label="Use compact density" type="checkbox" checked={preferences.compact} onChange={(event) => update({ ...preferences, compact: event.target.checked })} /></div>
    <div><span><strong>Reduce motion</strong><small>Disable non-essential transitions and chart motion while keeping interactions immediate.</small></span><input aria-label="Reduce workspace motion" type="checkbox" checked={preferences.reduceMotion} onChange={(event) => update({ ...preferences, reduceMotion: event.target.checked })} /></div>
  </div>;
}
