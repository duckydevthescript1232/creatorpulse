"use client";

import { startTransition, useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export function SyncButton({ enabled }: { enabled: boolean }) {
  const router = useRouter();
  const [state, setState] = useState<"idle" | "syncing" | "done" | "error">("idle");
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (state !== "done") return;
    const timer = window.setTimeout(() => { setState("idle"); setMessage(""); }, 2600);
    return () => window.clearTimeout(timer);
  }, [state]);

  async function sync() {
    if (!enabled || state === "syncing") return;
    setState("syncing");
    setMessage("Synchronizing the latest YouTube data…");
    try {
      const response = await fetch("/api/youtube/sync", { method: "POST", headers: { "content-type": "application/json" } });
      const body = await response.json() as { error?: string; videos?: number; truncated?: boolean };
      if (!response.ok) throw new Error(body.error ?? "Synchronization failed.");
      setState("done");
      setMessage(body.videos ? `Channel synchronized · ${body.videos} videos refreshed${body.truncated ? " (library limit reached)" : ""}` : "Channel synchronized");
      startTransition(() => router.refresh());
    } catch (error) {
      setState("error");
      setMessage(error instanceof Error ? error.message : "Synchronization failed.");
    }
  }

  return <div className="sync-control"><button className={`topbar-sync ${state}`} type="button" onClick={sync} disabled={!enabled || state === "syncing"}><span aria-hidden="true">{state === "done" ? "OK" : "SYNC"}</span>{state === "syncing" ? "Syncing…" : state === "done" ? "Synced" : state === "error" ? "Retry sync" : "Refresh"}</button>{message && <div className={`toast ${state}`} role={state === "error" ? "alert" : "status"}><strong>{state === "error" ? "Sync failed" : message}</strong>{state === "error" && <span>{message}</span>}</div>}</div>;
}
