/* eslint-disable @next/next/no-img-element */
"use client";

import { useEffect, useMemo, useState } from "react";
import type { VideoRecord } from "@/lib/domain/types";
import { descriptionSuggestion, scoreDescription, scoreTags, scoreTitle, tagSuggestions, titleSuggestions } from "@/lib/optimization/video";

type Draft = { title: string; description: string; tags: string[] };
type SaveState = "idle" | "saving" | "saved" | "error";

function compact(value: number) { return new Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 1 }).format(value); }
function initialDraft(video: VideoRecord): Draft { return { title: video.title, description: video.description ?? "", tags: video.tags ?? [] }; }
function savedDraft(video: VideoRecord): Draft {
  if (typeof window === "undefined") return initialDraft(video);
  try {
    const stored = window.localStorage.getItem(`creatorpulse-draft-${video.id}`);
    if (!stored) return initialDraft(video);
    const parsed = JSON.parse(stored) as Partial<Draft>;
    return { title: typeof parsed.title === "string" ? parsed.title : video.title, description: typeof parsed.description === "string" ? parsed.description : video.description ?? "", tags: Array.isArray(parsed.tags) ? parsed.tags.filter((tag): tag is string => typeof tag === "string") : video.tags ?? [] };
  } catch { return initialDraft(video); }
}

export function VideoManager({ videos, initialVideoId, writable, totalUploadCount }: { videos: VideoRecord[]; initialVideoId?: string; writable: boolean; totalUploadCount?: number }) {
  const [videoState, setVideoState] = useState(videos);
  const [selectedId, setSelectedId] = useState(initialVideoId ?? videos[0]?.id ?? "");
  const selected = videoState.find((video) => video.id === selectedId) ?? videoState[0];
  const [query, setQuery] = useState("");
  const [format, setFormat] = useState("All");
  const [draft, setDraft] = useState<Draft>(() => initialDraft(selected));
  const [tagInput, setTagInput] = useState("");
  const [saveState, setSaveState] = useState<SaveState>("idle");
  const [message, setMessage] = useState("");
  const [optimizeOpen, setOptimizeOpen] = useState(false);

  const filtered = useMemo(() => videoState.filter((video) => (format === "All" || video.format === format) && video.title.toLowerCase().includes(query.trim().toLowerCase())), [videoState, query, format]);
  const original = initialDraft(selected);
  const changed = draft.title !== original.title || draft.description !== original.description || draft.tags.join("\0") !== original.tags.join("\0");
  const titleScore = scoreTitle(draft.title);
  const descriptionScore = scoreDescription(selected.description === undefined ? undefined : draft.description);
  const tagScore = scoreTags(selected.tags === undefined ? undefined : draft.tags);
  const scores = [titleScore.score, descriptionScore.score, tagScore.score].filter((score): score is number => score !== null);
  const totalScore = scores.length ? Math.round(scores.reduce((sum, score) => sum + score, 0) / scores.length) : null;
  const titleOptions = titleSuggestions(selected);
  const suggestedDescription = descriptionSuggestion(selected, original.description);
  const suggestedTags = tagSuggestions(selected, videoState);
  const optimizedDraft: Draft = {
    title: titleOptions[0] ?? draft.title,
    description: selected.description === undefined ? draft.description : suggestedDescription,
    tags: selected.tags === undefined ? draft.tags : [...new Set([...draft.tags, ...suggestedTags])].slice(0, 30),
  };
  const tagChars = draft.tags.join(",").length;
  const validationError = !draft.title.trim() ? "A YouTube title cannot be empty." : draft.title.length > 100 ? "The title is over 100 characters." : tagChars > 500 ? "Tags are over the 500-character limit." : "";

  useEffect(() => {
    if (!selected) return;
    const frame = window.requestAnimationFrame(() => {
      setDraft(savedDraft(selected));
      setSaveState("idle");
      setMessage("");
      setTagInput("");
    });
    return () => window.cancelAnimationFrame(frame);
  }, [selected]);
  useEffect(() => {
    if (!selected || !changed) return;
    window.localStorage.setItem(`creatorpulse-draft-${selected.id}`, JSON.stringify(draft));
  }, [changed, draft, selected]);
  useEffect(() => {
    if (!optimizeOpen) return;
    const close = (event: KeyboardEvent) => { if (event.key === "Escape") setOptimizeOpen(false); };
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, [optimizeOpen]);

  function chooseVideo(id: string) {
    const next = videoState.find((video) => video.id === id);
    if (!next) return;
    setSelectedId(id);
    window.history.replaceState(null, "", `/videos?video=${encodeURIComponent(id)}`);
  }

  function addTag(value = tagInput) {
    const clean = value.trim();
    if (!clean || draft.tags.some((tag) => tag.toLowerCase() === clean.toLowerCase())) return;
    const nextTags = [...draft.tags, clean];
    if (nextTags.join(",").length > 500) { setMessage("That tag would exceed the 500-character tag limit."); return; }
    setDraft({ ...draft, tags: nextTags });
    setTagInput("");
  }

  async function copyText(value: string, label = "Title copied") {
    try { await navigator.clipboard.writeText(value); setMessage(label); }
    catch { setMessage("Copy is unavailable in this browser. Select the text and copy it manually."); }
  }

  async function save() {
    if (!writable || !changed || saveState === "saving" || validationError) {
      if (validationError) setMessage(validationError);
      return;
    }
    setSaveState("saving");
    setMessage("Saving your confirmed changes...");
    try {
      const response = await fetch(`/api/videos/${encodeURIComponent(selected.id)}/metadata`, { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify(draft) });
      const body = await response.json() as { error?: string; metadata?: Draft };
      if (!response.ok || !body.metadata) throw new Error(body.error ?? "YouTube could not save this video.");
      const metadata = body.metadata;
      setVideoState((current) => current.map((video) => video.id === selected.id ? { ...video, title: metadata.title, description: metadata.description, tags: metadata.tags, metadataSyncedAt: new Date().toISOString() } : video));
      setDraft(metadata);
      window.localStorage.removeItem(`creatorpulse-draft-${selected.id}`);
      setSaveState("saved");
      setMessage("✓ Video updated on YouTube");
      window.setTimeout(() => setSaveState("idle"), 2200);
    } catch (error) {
      setSaveState("error");
      setMessage(error instanceof Error ? error.message : "Could not save. Your draft is still here.");
    }
  }

  if (!selected) return null;
  const visibleCount = videoState.length;
  const libraryLabel = totalUploadCount && totalUploadCount > visibleCount ? `${visibleCount} loaded / ${totalUploadCount} uploads` : `${visibleCount} uploads`;

  return <div className="video-manager">
    <aside className="video-library">
      <div className="library-heading"><div><span>VIDEO LIBRARY</span><strong>{libraryLabel}</strong></div><label><span className="sr-only">Search videos</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search titles" /></label><div className="filter-tabs">{["All", "Long-form", "Short", "Stream"].map((item) => <button type="button" aria-pressed={format === item} className={format === item ? "active" : ""} onClick={() => setFormat(item)} key={item}>{item}</button>)}</div></div>
      <div className="video-library-list">{filtered.length ? filtered.map((video) => <button type="button" className={video.id === selected.id ? "active" : ""} onClick={() => chooseVideo(video.id)} key={video.id}>{video.thumbnailUrl ? <img src={video.thumbnailUrl} alt="" /> : <span className="library-thumb">{video.format.slice(0, 1)}</span>}<span><strong>{video.title}</strong><small>{compact(video.views)} views · {new Date(video.publishedAt).toLocaleDateString("en-US")}</small></span></button>) : <div className="library-empty"><strong>No matching videos</strong><span>Try another search or format.</span></div>}</div>
    </aside>

    <section className="video-workspace">
      <header className="workspace-title"><div><span>{writable ? "LIVE YOUTUBE VIDEO" : "PUBLIC VIDEO ANALYSIS · LOCAL TITLE DRAFT"}</span><h1>{selected.title}</h1><p>{selected.privacyStatus ? `${selected.privacyStatus} · ` : ""}Last metadata sync {selected.metadataSyncedAt ? new Date(selected.metadataSyncedAt).toLocaleString("en-US") : "unavailable"}</p></div><button type="button" className="button secondary" onClick={() => setOptimizeOpen(true)}>Optimize Video</button></header>
      <div className="editor-layout"><div className="metadata-editor">
        <section><div className="field-heading"><div><span>Title</span><small>{draft.title.length} / 100 characters</small></div><button type="button" onClick={() => setDraft({ ...draft, title: original.title })} disabled={draft.title === original.title}>Undo</button></div><input className="title-input" value={draft.title} onChange={(event) => setDraft({ ...draft, title: event.target.value.slice(0, 100) })} />{titleOptions.length ? <div className="suggestion-stack"><span>CreatorPulse directions</span>{titleOptions.map((suggestion) => <article key={suggestion}><p>{suggestion}</p><div><button type="button" onClick={() => setDraft({ ...draft, title: suggestion })}>Use suggestion</button><button type="button" onClick={() => copyText(suggestion, "Suggestion copied")}>Copy</button></div></article>)}</div> : <p className="preservation-note">Your current title is already the strongest deterministic option CreatorPulse can justify from this metadata.</p>}</section>
        <section><div className="field-heading"><div><span>Description</span><small>{draft.description.length} / 5,000 characters</small></div><button type="button" onClick={() => setDraft({ ...draft, description: original.description })} disabled={draft.description === original.description}>Undo</button></div>{selected.description === undefined ? <div className="unavailable-field">Unavailable from public channel data. Connect YouTube to load and edit the complete description.</div> : <textarea value={draft.description} onChange={(event) => setDraft({ ...draft, description: event.target.value.slice(0, 5000) })} disabled={!writable} rows={13} />}<p className="preservation-note">Existing links, credits, timestamps, hashtags, and formatting are preserved unless you edit them.</p></section>
        <section><div className="field-heading"><div><span>Tags</span><small>{draft.tags.length} unique tags · {tagChars} / 500 characters</small></div><button type="button" onClick={() => setDraft({ ...draft, tags: original.tags })} disabled={draft.tags.join() === original.tags.join()}>Undo</button></div>{selected.tags === undefined ? <div className="unavailable-field">Tags are private metadata. Connect YouTube to retrieve them.</div> : <><div className="tag-pills">{draft.tags.map((tag) => <span key={tag}>{tag}<button type="button" aria-label={`Remove ${tag}`} onClick={() => setDraft({ ...draft, tags: draft.tags.filter((item) => item !== tag) })}>×</button></span>)}</div><div className="tag-entry"><input value={tagInput} onChange={(event) => setTagInput(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); addTag(); } }} placeholder="Add a relevant tag" /><button type="button" onClick={() => addTag()}>Add tag</button></div>{suggestedTags.length > 0 && <div className="suggested-tags"><span>Relevant from this channel</span><div>{suggestedTags.slice(0, 6).map((tag) => <button type="button" key={tag} onClick={() => addTag(tag)}>+ {tag}</button>)}</div></div>}</>}</section>
        <footer className="save-bar"><div><strong>{validationError ? "Fix metadata before saving" : changed ? "Draft changes ready" : "Metadata is up to date"}</strong><span>{message || validationError || (writable ? "Changes stay in this draft until you confirm." : "Public mode never pretends private metadata is available. Connect YouTube to edit on-platform.")}</span></div>{writable ? <button type="button" className={`button save-button ${saveState}`} onClick={save} disabled={!changed || saveState === "saving" || Boolean(validationError)}>{saveState === "saving" ? "Saving..." : saveState === "saved" ? "✓ Saved to YouTube" : saveState === "error" ? "Couldn't save — Retry" : "Save to YouTube"}</button> : <button type="button" className="button save-button" onClick={() => copyText(draft.title, "Optimized title copied")} disabled={!draft.title.trim()}>Copy title</button>}</footer>
      </div>
      <aside className="optimization-panel"><div className="optimization-score"><span>CREATORPULSE SCORE</span><strong>{totalScore ?? "—"}</strong><small>{totalScore === null ? "Not enough metadata" : "Explainable metadata quality"}</small></div>{[["Title strength", titleScore], ["Description quality", descriptionScore], ["Keyword coverage", tagScore]].map(([label, result]) => { const scored = result as typeof titleScore; return <section key={label as string}><div><span>{label as string}</span><strong>{scored.score ?? "—"}</strong></div><b>{scored.label}</b>{scored.reasons.map((reason) => <p className={reason.tone} key={reason.text}>{reason.text}</p>)}</section>; })}<div className="score-disclaimer"><strong>Recommendation, not a ranking promise</strong><p>Scores explain metadata clarity. They do not predict views or guarantee YouTube distribution.</p></div></aside></div>
    </section>

    {optimizeOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setOptimizeOpen(false); }}><div className="optimize-modal" role="dialog" aria-modal="true" aria-labelledby="optimize-title"><header><div><span>BEFORE / AFTER WORKSPACE</span><h2 id="optimize-title">Optimize Video</h2><p>CreatorPulse proposes deterministic changes from real metadata and channel wording. Review every change before saving.</p></div><button type="button" aria-label="Close optimization workspace" onClick={() => setOptimizeOpen(false)}>×</button></header><div className="compare-grid"><section><span>CURRENT</span><h3>{original.title}</h3><p>{original.description || "No description available."}</p><div className="tag-pills">{original.tags.map((tag) => <span key={tag}>{tag}</span>)}</div></section><section><span>CREATORPULSE VERSION</span><h3>{optimizedDraft.title}</h3><p>{optimizedDraft.description || "No description changes proposed."}</p><div className="tag-pills">{optimizedDraft.tags.map((tag) => <span key={tag}>{tag}</span>)}</div></section></div><footer className="optimize-actions"><button type="button" className="button secondary" onClick={() => setDraft({ ...draft, title: optimizedDraft.title })}>Apply Title</button>{selected.description !== undefined && <button type="button" className="button secondary" onClick={() => setDraft({ ...draft, description: optimizedDraft.description })}>Apply Description</button>}{selected.tags !== undefined && <button type="button" className="button secondary" onClick={() => setDraft({ ...draft, tags: optimizedDraft.tags })}>Apply Tags</button>}<button type="button" className="button secondary" onClick={() => setDraft(optimizedDraft)}>Apply All</button>{writable ? <button type="button" className="button" onClick={() => { setOptimizeOpen(false); void save(); }} disabled={!changed || Boolean(validationError)}>Confirm current draft & Save</button> : <button type="button" className="button" onClick={() => { void copyText(optimizedDraft.title, "Optimized title copied"); setOptimizeOpen(false); }}>Copy suggested title</button>}</footer></div></div>}
  </div>;
}
