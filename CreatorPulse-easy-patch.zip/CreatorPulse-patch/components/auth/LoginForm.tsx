"use client";

import { useState } from "react";

export function LoginForm({ returnTo }: { returnTo: string | null }) {
  const [status, setStatus] = useState<"idle" | "loading" | "success">("idle");
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (status === "loading") return;
    setError("");
    setStatus("loading");
    const data = new FormData(event.currentTarget);
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          email: data.get("email"),
          password: data.get("password"),
          remember: data.get("remember") === "on",
          returnTo,
        }),
      });
      const body = await response.json() as { error?: string; destination?: string };
      if (!response.ok || !body.destination) throw new Error(body.error ?? "Sign in failed.");
      setStatus("success");
      window.location.assign(body.destination);
    } catch (reason) {
      setStatus("idle");
      setError(reason instanceof Error ? reason.message : "Sign in failed.");
    }
  }

  return <form className="account-login-form" onSubmit={submit}>
    {error && <div className="auth-inline-error" role="alert"><i />{error}</div>}
    <label htmlFor="account-email"><span>Email address</span><input id="account-email" name="email" type="email" autoComplete="email" required maxLength={254} /></label>
    <label htmlFor="account-password"><span>Password</span><input id="account-password" name="password" type="password" autoComplete="current-password" required maxLength={256} /></label>
    <div className="login-options"><label><input name="remember" type="checkbox" /><span>Remember me</span></label></div>
    <button className={`button full auth-submit ${status}`} type="submit" disabled={status === "loading" || status === "success"}>
      <span>{status === "loading" ? "Signing in…" : status === "success" ? "✓ Signed in" : "Sign in"}</span><b aria-hidden="true">→</b>
    </button>
  </form>;
}
