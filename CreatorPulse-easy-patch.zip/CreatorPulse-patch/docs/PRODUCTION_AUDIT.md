# CreatorPulse production audit

Date: 2026-08-14

## Goal

Make the existing project behave like a finished creator workspace: real data where available, explicit read-only/unavailable states where it is not, fast route perception, safe YouTube writes, and no authenticated demo substitution.

## High-impact fixes made

### Navigation and performance

- Activated the persistent `AppFrame` so the workspace sidebar/topbar stay mounted.
- Stopped `HardLink` from disabling framework prefetch by default.
- Added immediate pending-route state and a destination `RouteSkeleton` instead of leaving the previous page frozen while data loads.
- Shortened route/motion timing and removed animation patterns that should not gate navigation.
- YouTube sync updates success state immediately and refreshes route data in a React transition.

### Authentication and ownership

- Login is email/password first.
- Platform identity fallback is disabled unless explicitly enabled by environment configuration.
- Admin is a server-side database role, bootstrapped only after the configured admin password hash verifies.
- YouTube handle, CreatorPulse admin role, and Google OAuth channel ownership are separate.

### YouTube integration

- OAuth uses PKCE and server-only encrypted tokens.
- Manual sync paginates uploads and batches video reads.
- Connected daily Analytics data covers up to 365 days.
- Metadata update verifies the video belongs to the connected channel, retrieves the current snippet, merges user changes, preserves required fields, and only then writes.
- The Video Manager keeps unsaved drafts if a network/API save fails.

### Product tools

- Video Manager: real library, search/filter, metadata editor, optimization comparison, explicit save, draft persistence.
- Analytics: real daily YouTube Analytics when connected; honest publish-date sample fallback otherwise.
- Growth Plan: channel-relative evidence plus creator-brief constraints; Pro entitlement enforced.
- Ideas: channel-signal concepts instead of one-keyword generic templates.
- View Planner: persisted production items and optimistic interactions.
- Launch Lab: working deterministic output, copy/save/download, with explicit hypothesis limitations.
- Settings preferences: removed a toggle that did not control real notifications; density and reduced motion now persist and apply.
- Export: up to 500 loaded videos in CSV.

## Source-level checks

- All statically referenced internal page links and form/API actions resolve to routes present in the project.
- No `type="button"` control was found without an action except intentionally disabled controls.
- Authenticated dashboard source contains no demo-channel import/substitution.
- Current automated test suite: 32/32 passing.
- TypeScript and ESLint checks pass.

## Before real-channel use

1. Install dependencies fresh on the deployment platform (`npm ci`).
2. Configure admin credentials and secrets from `.env.example`.
3. Apply database migrations.
4. Configure the Google OAuth client and exact callback URL.
5. Sign in and add the real YouTube @handle.
6. Connect YouTube and confirm the connected channel ID is correct.
7. Run sync and confirm real videos + 28/90/365-day Analytics where the plan allows them.
8. Open a low-risk test video, make a reversible title/description/tag change, save, verify in YouTube Studio, reload CreatorPulse, then restore it.
9. Verify disconnect/reconnect.
10. Only enable live billing after PayPal sandbox webhooks pass.

## Remaining deployment caveats

A code audit cannot manufacture or validate external Google/YouTube/PayPal credentials. The product now exposes those missing states honestly instead of masking them as successful features. A fresh production build and the real-account smoke test above are the final requirements before relying on the site for day-to-day channel management.
