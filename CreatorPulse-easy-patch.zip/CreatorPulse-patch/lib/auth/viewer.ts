import { and, eq, gt } from "drizzle-orm";
import { env } from "cloudflare:workers";
import { getDb } from "@/db";
import { sessions, users } from "@/db/schema";
import { getPlatformAccountAction } from "@/lib/auth/platform-account";
import { hashSessionToken, readSessionToken } from "@/lib/auth/session";

export type AuthenticatedViewer = {
  id: string;
  email: string;
  name: string;
  role: "ADMIN" | "USER";
};

function decodePlatformName(headers: Headers): string | null {
  const encoded = headers.get("oai-authenticated-user-full-name");
  if (!encoded || headers.get("oai-authenticated-user-full-name-encoding") !== "percent-encoded-utf-8") return null;
  try { return decodeURIComponent(encoded); } catch { return null; }
}

async function getPlatformViewer(headers: Headers): Promise<AuthenticatedViewer | null> {
  const platformId = headers.get("oai-authenticated-user-id");
  const platformEmail = headers.get("oai-authenticated-user-email")?.trim().toLowerCase();
  if (!platformId || !platformEmail) return null;
  const runtime = env as unknown as { CREATORPULSE_ADMIN_EMAIL?: string };
  const isAdminEmail = platformEmail === runtime.CREATORPULSE_ADMIN_EMAIL?.trim().toLowerCase();
  const db = getDb();
  const existing = (await db.select().from(users).where(eq(users.email, platformEmail)).limit(1))[0] ?? null;
  const now = new Date();
  const role = isAdminEmail ? "ADMIN" as const : existing?.role ?? "USER" as const;
  const name = decodePlatformName(headers) ?? existing?.name ?? platformEmail.split("@")[0];
  const accountAction = getPlatformAccountAction(existing, name, role);
  if (accountAction === "update" && existing) await db.update(users).set({ name, role, updatedAt: now }).where(eq(users.id, existing.id));
  if (accountAction === "insert") await db.insert(users).values({ id: platformId, email: platformEmail, name, role, createdAt: now, updatedAt: now });
  return { id: existing?.id ?? platformId, email: platformEmail, name, role };
}

export async function getAuthenticatedViewer(headers: Headers): Promise<AuthenticatedViewer | null> {
  const token = readSessionToken(headers);
  if (token) {
    const row = (await getDb().select({ id: users.id, email: users.email, name: users.name, role: users.role }).from(sessions).innerJoin(users, eq(sessions.userId, users.id)).where(and(eq(sessions.id, await hashSessionToken(token)), gt(sessions.expiresAt, new Date()))).limit(1))[0];
    if (row) return { id: row.id, email: row.email, name: row.name ?? row.email.split("@")[0], role: row.role };
  }
  const runtime = env as unknown as { CREATORPULSE_ALLOW_PLATFORM_AUTH?: string };
  return runtime.CREATORPULSE_ALLOW_PLATFORM_AUTH === "true" ? getPlatformViewer(headers) : null;
}

export async function requireAuthenticatedViewer(headers: Headers): Promise<AuthenticatedViewer> {
  const viewer = await getAuthenticatedViewer(headers);
  if (!viewer) throw new Error("AUTHENTICATION_REQUIRED");
  return viewer;
}

export function assertSameOrigin(request: Request): void {
  const origin = request.headers.get("origin");
  if (!origin || origin !== new URL(request.url).origin) throw new Error("INVALID_REQUEST_ORIGIN");
}
