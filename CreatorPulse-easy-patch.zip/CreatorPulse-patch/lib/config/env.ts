type RuntimeConfig = {
  googleConfigured: boolean;
  paypalConfigured: boolean;
};

export function getRuntimeConfig(env: Record<string, string | undefined> = process.env): RuntimeConfig {
  return {
    googleConfigured: Boolean(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET && env.GOOGLE_REDIRECT_URI && env.YOUTUBE_TOKEN_ENCRYPTION_KEY),
    paypalConfigured: Boolean(env.PAYPAL_CLIENT_ID && env.PAYPAL_CLIENT_SECRET && env.PAYPAL_PRO_PLAN_ID && env.PAYPAL_CREATOR_PLUS_PLAN_ID),
  };
}

export function assertProductionConfig(env: Record<string, string | undefined> = process.env): void {
  if (env.NODE_ENV !== "production") return;
  const required = ["APP_URL", "APP_SESSION_SECRET"];
  const missing = required.filter((key) => !env[key]);
  if (missing.length > 0) throw new Error(`Missing required production configuration: ${missing.join(", ")}`);
}
