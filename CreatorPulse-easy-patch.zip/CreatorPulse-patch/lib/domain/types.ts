export type Confidence = "Low" | "Medium" | "High";
export type VideoFormat = "Short" | "Long-form" | "Stream";
export type PerformanceLabel = "Breakout" | "Strong" | "Typical" | "Weak";

export interface VideoRecord {
  id: string;
  title: string;
  publishedAt: string;
  durationSeconds: number;
  format: VideoFormat;
  topic: string;
  views: number;
  likes?: number;
  comments?: number;
  subscribersGained?: number;
  description?: string;
  tags?: string[];
  categoryId?: string;
  privacyStatus?: string;
  thumbnailUrl?: string;
  defaultLanguage?: string;
  defaultAudioLanguage?: string;
  metadataSyncedAt?: string;
}

export type PlannerStatus = "idea" | "planned" | "recording" | "published";

export interface PlannerItem {
  id: string;
  workingTitle: string;
  topic: string;
  targetDate: string | null;
  format: VideoFormat;
  notes: string;
  status: PlannerStatus;
  tags: string[];
  thumbnailIdea: string;
  position: number;
}

export interface ScoreResult {
  score: number;
  confidence: Confidence;
  explanation: string;
  factors: Array<{ label: string; impact: "positive" | "neutral" | "negative" }>;
}

export interface ChannelOverview {
  id: string;
  name: string;
  handle: string;
  niche: string;
  subscriberCount: number;
  totalViews: number;
  uploadCount: number;
  watchHours28d: number;
  views28d: number;
  viewsPrevious28d: number;
  subscriberChange28d: number;
  lastUpdatedAt: string;
}
