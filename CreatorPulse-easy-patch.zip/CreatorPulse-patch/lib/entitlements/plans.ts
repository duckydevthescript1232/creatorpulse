export type Plan = "free" | "pro" | "creator_plus";
export type Entitlements = { channels: number; viewPlannerStrategies: number; ideasPerMonth: number; historyDays: number; dailyGrowthPlan: boolean };

export const planEntitlements: Record<Plan, Entitlements> = {
  free: { channels: 1, viewPlannerStrategies: 1, ideasPerMonth: 10, historyDays: 28, dailyGrowthPlan: false },
  pro: { channels: 1, viewPlannerStrategies: 3, ideasPerMonth: 200, historyDays: 365, dailyGrowthPlan: true },
  creator_plus: { channels: 1, viewPlannerStrategies: 3, ideasPerMonth: 600, historyDays: 365, dailyGrowthPlan: true },
};

export function canUse(plan: Plan, feature: keyof Entitlements): boolean {
  const value = planEntitlements[plan][feature];
  return typeof value === "boolean" ? value : value > 0;
}
