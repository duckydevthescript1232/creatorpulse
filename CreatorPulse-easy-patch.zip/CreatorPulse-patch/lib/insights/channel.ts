import type { Confidence, VideoFormat, VideoRecord } from "@/lib/domain/types";
import { confidenceFor, performanceRatio, scoreVideo } from "@/lib/scoring/engine";

const stopWords = new Set(["about", "after", "again", "against", "best", "could", "every", "from", "game", "games", "have", "into", "most", "that", "their", "these", "this", "those", "through", "video", "what", "when", "where", "which", "while", "with", "without", "your", "youtube"]);

export function compactNumber(value: number | null | undefined): string { return value === null || value === undefined ? "Unavailable" : new Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 1 }).format(value); }
export function median(values: number[]): number { if (!values.length) return 0; const sorted = [...values].sort((a, b) => a - b); const middle = Math.floor(sorted.length / 2); return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2; }
export function durationLabel(seconds: number): string { if (!seconds) return "Public"; return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`; }

export function formatSummary(videos: VideoRecord[]) {
  const formats: VideoFormat[] = ["Short", "Long-form", "Stream"];
  return formats.map((format) => { const matches = videos.filter((video) => video.format === format); return { format, uploads: matches.length, views: matches.reduce((sum, video) => sum + video.views, 0), medianViews: median(matches.map((video) => video.views)) }; }).filter((item) => item.uploads > 0).sort((a, b) => b.medianViews - a.medianViews);
}

function titleTokens(title: string): string[] { return title.toLowerCase().match(/[a-z0-9]{4,}/g)?.filter((word) => !stopWords.has(word)) ?? []; }
export function topicSignals(videos: VideoRecord[]) {
  const grouped = new Map<string, VideoRecord[]>();
  for (const video of videos) for (const token of new Set(titleTokens(video.title)).values()) grouped.set(token, [...(grouped.get(token) ?? []), video]);
  return [...grouped.entries()].filter(([, items]) => items.length >= 2).map(([topic, items]) => ({ topic: topic[0].toUpperCase() + topic.slice(1), uploads: items.length, medianViews: median(items.map((item) => item.views)), confidence: confidenceFor(items.length, 2) })).sort((a, b) => b.medianViews - a.medianViews).slice(0, 6);
}

export function strongestVideo(videos: VideoRecord[]): VideoRecord | null { return [...videos].filter((video) => video.views > 0).sort((a, b) => performanceRatio(b, videos) - performanceRatio(a, videos))[0] ?? null; }

export function growthRecommendation(videos: VideoRecord[]) {
  const best = strongestVideo(videos); if (!best) return null; const ratio = performanceRatio(best, videos); const score = scoreVideo(best, videos); const topic = titleTokens(best.title)[0] ?? "winning";
  return { best, ratio, score, topic: topic[0].toUpperCase() + topic.slice(1), headline: `Create a distinct follow-up to “${best.title}”`, explanation: `This ${best.format.toLowerCase()} delivered ${ratio.toFixed(1)}× the median views of comparable uploads. Preserve its audience promise and format while changing the scenario, constraint, or outcome.`, experiment: best.format === "Short" ? "Make the value or tension clear in the first two seconds." : "Confirm the core promise in the opening 30 seconds and remove setup that delays it." };
}

export function generateIdeas(videos: VideoRecord[], goal: string) {
  const usable = videos.filter((video) => video.views > 0);
  const best = strongestVideo(usable);
  if (!best) return [];
  const signals = topicSignals(usable).slice(0, 3);
  const bestTokens = titleTokens(best.title).slice(0, 3);
  const primary = signals[0]?.topic ?? bestTokens[0] ?? "your strongest topic";
  const secondary = signals[1]?.topic ?? bestTokens[1] ?? primary;
  const confidence: Confidence = confidenceFor(usable.length, signals.length ? 3 : 2);
  const ratio = performanceRatio(best, usable);
  const score = scoreVideo(best, usable).score;
  const bestFormat = best.format;
  const alternate: VideoFormat = bestFormat === "Short" ? "Long-form" : "Short";

  const concepts = goal === "subscribers" ? [
    { title: `${primary}: turn the strongest result into a repeatable series`, format: bestFormat, why: `Your strongest upload is ${ratio.toFixed(1)}× its format median. Repeat the audience promise, not the exact video.` },
    { title: `A beginner-friendly ${primary} follow-up with one clear payoff`, format: alternate, why: `Transfer the proven ${primary} signal into ${alternate.toLowerCase()} while making the value obvious to a new viewer.` },
    { title: `${primary} vs ${secondary}: which one is actually worth it?`, format: bestFormat, why: `Two recurring channel signals create a comparison that can serve both returning and new viewers.` },
    { title: `What I wish I knew before trying ${primary}`, format: alternate, why: `A learning-led follow-up keeps the topic familiar while changing the viewer promise.` },
  ] : goal === "retention" ? [
    { title: `${best.title.replace(/[!?]+$/, "")} — but the hardest part comes first`, format: bestFormat, why: `Keep the strongest proven concept and move the highest-tension moment earlier in the structure.` },
    { title: `${primary}: one escalating rule from start to finish`, format: bestFormat, why: `An escalating constraint gives the viewer a clear reason to stay for the next beat.` },
    { title: `Can ${primary} get harder every minute?`, format: alternate, why: `A visible progression creates natural retention checkpoints in a complementary format.` },
    { title: `${primary}: reveal the result before explaining how it happened`, format: bestFormat, why: `Outcome-first packaging lets you test whether earlier payoff improves viewer continuation.` },
  ] : [
    { title: `A new scenario built around ${primary}`, format: bestFormat, why: `Closest controlled follow-up to the strongest recurring topic while avoiding a copy of the winning upload.` },
    { title: `${primary} with one constraint you have not tested yet`, format: bestFormat, why: `Preserves the topic and format signal while changing one variable you can measure.` },
    { title: `Turn ${primary} into a ${alternate.toLowerCase()} experiment`, format: alternate, why: `Tests whether the audience promise transfers to another format without assuming it will.` },
    { title: `${primary} + ${secondary}: combine two proven channel signals`, format: bestFormat, why: `Uses recurring title themes from your own uploads instead of a random trend prompt.` },
  ];

  return concepts.map((concept, index) => ({
    title: concept.title.slice(0, 100),
    format: concept.format,
    score: Math.max(58, Math.round(score - index * 5)),
    rationale: `${concept.why} Evidence: “${best.title}” is currently the strongest format-relative upload in the analyzed sample.`,
    confidence: index === 0 ? confidence : index === 1 && confidence === "High" ? "Medium" as Confidence : "Low" as Confidence,
  }));
}
