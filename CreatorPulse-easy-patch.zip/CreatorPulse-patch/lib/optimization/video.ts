import type { VideoRecord } from "@/lib/domain/types";

export type ExplainableScore = { score: number | null; label: string; reasons: Array<{ text: string; tone: "positive" | "neutral" | "warning" }> };

const stopWords = new Set(["this", "that", "with", "from", "your", "have", "what", "when", "where", "which", "about", "into", "after", "before", "using", "only", "video", "youtube", "the", "and", "for", "but", "you", "are", "was", "were", "how", "why"]);

export function metadataKeywords(title: string): string[] {
  return [...new Set(title.toLowerCase().replace(/[^a-z0-9\s-]/g, " ").split(/\s+/).map((word) => word.trim()).filter((word) => word.length >= 3 && !stopWords.has(word)))].slice(0, 8);
}

export function scoreTitle(title: string): ExplainableScore {
  const clean = title.trim();
  if (!clean) return { score: null, label: "Not enough data", reasons: [{ text: "Add a working title to evaluate it.", tone: "neutral" }] };
  const length = clean.length;
  const words = clean.split(/\s+/).filter(Boolean);
  const concrete = /\d|only|without|hardest|easiest|first|last|before|after|challenge|test|tried|built|made|vs\.?/i.test(clean);
  const readable = words.length >= 4 && words.length <= 14;
  let score = 50;
  score += length >= 30 && length <= 75 ? 22 : length <= 100 ? 10 : -25;
  score += readable ? 12 : 2;
  score += concrete ? 12 : 4;
  score = Math.max(20, Math.min(96, score));
  return {
    score,
    label: score >= 82 ? "Strong" : score >= 68 ? "Solid foundation" : "Needs clarity",
    reasons: [
      { text: length >= 30 && length <= 75 ? "The title is concise enough to scan while still carrying context." : length > 100 ? "The title exceeds YouTube's 100-character limit." : "Aim for a clear promise without padding the title.", tone: length >= 30 && length <= 75 ? "positive" : "warning" },
      { text: concrete ? "It contains a concrete scenario, constraint, or outcome." : "Make the viewer promise more specific instead of adding generic hype.", tone: concrete ? "positive" : "neutral" },
      { text: readable ? "The word count is easy to parse quickly." : "Shorten or simplify the phrasing so the core idea is obvious at a glance.", tone: readable ? "positive" : "neutral" },
    ],
  };
}

export function scoreDescription(description: string | undefined): ExplainableScore {
  if (description === undefined) return { score: null, label: "Unavailable", reasons: [{ text: "Connect YouTube to load the real description.", tone: "neutral" }] };
  const text = description.trim();
  if (!text) return { score: 28, label: "Needs context", reasons: [{ text: "The description is empty.", tone: "warning" }] };
  const firstLine = text.split("\n")[0]?.trim() ?? "";
  const hasUsefulOpening = firstLine.length >= 30 && firstLine.length <= 180;
  const hasStructure = text.includes("\n");
  const score = Math.min(94, 48 + (text.length >= 100 ? 16 : 7) + (hasUsefulOpening ? 18 : 5) + (hasStructure ? 8 : 0));
  return {
    score,
    label: score >= 80 ? "Well structured" : "Can be improved",
    reasons: [
      { text: hasUsefulOpening ? "The opening gives viewers useful context before secondary details." : "Lead with one concise sentence explaining what the viewer gets from this video.", tone: hasUsefulOpening ? "positive" : "neutral" },
      { text: "Existing links, timestamps, credits, and hashtags stay untouched unless you edit them.", tone: "positive" },
    ],
  };
}

export function scoreTags(tags: string[] | undefined): ExplainableScore {
  if (tags === undefined) return { score: null, label: "Unavailable", reasons: [{ text: "Tags are private metadata; connect YouTube to load them.", tone: "neutral" }] };
  const clean = tags.map((tag) => tag.trim()).filter(Boolean);
  const unique = new Set(clean.map((tag) => tag.toLowerCase()));
  const duplicateCount = clean.length - unique.size;
  const totalChars = clean.join(",").length;
  let score = clean.length ? 58 : 35;
  if (unique.size >= 3 && unique.size <= 12) score += 20;
  if (duplicateCount === 0) score += 8;
  if (totalChars <= 500) score += 8; else score -= 30;
  score = Math.max(20, Math.min(94, score));
  return {
    score,
    label: clean.length ? "Relevant coverage" : "No tags",
    reasons: [
      { text: clean.length ? `${unique.size} unique tags are available. Relevance matters more than filling the limit.` : "Add only tags that accurately describe the actual video.", tone: clean.length ? "positive" : "neutral" },
      { text: duplicateCount ? `${duplicateCount} duplicate tag${duplicateCount === 1 ? "" : "s"} should be removed.` : "No duplicate tags detected.", tone: duplicateCount ? "warning" : "positive" },
      { text: totalChars <= 500 ? `${totalChars} / 500 tag characters used.` : "The combined tag text is over the supported limit.", tone: totalChars <= 500 ? "neutral" : "warning" },
    ],
  };
}

export function titleSuggestions(video: VideoRecord): string[] {
  const base = video.title.trim().replace(/[!?]+$/, "");
  const keywords = metadataKeywords(base);
  const topic = keywords.slice(0, 3).join(" ") || base;
  const candidates = [
    base,
    /^i\s/i.test(base) ? `${base} — Here’s What Happened` : `I Tried ${topic} — Here’s What Happened`,
    /challenge|test|escape|game|build|make|tried?/i.test(base) ? `${base}: The Hardest Part` : `${topic}: What I Learned`,
  ];
  return [...new Set(candidates.map((value) => value.slice(0, 100)).filter((value) => value && value !== video.title))].slice(0, 3);
}

export function descriptionSuggestion(video: VideoRecord, currentDescription: string): string {
  const opening = `In this video: ${video.title.replace(/[.!?]+$/, "")}.`;
  const clean = currentDescription.trim();
  if (!clean) return opening;
  if (clean.toLowerCase().startsWith(opening.toLowerCase())) return currentDescription;
  return `${opening}\n\n${currentDescription}`.slice(0, 5000);
}

export function tagSuggestions(video: VideoRecord, allVideos: VideoRecord[] = []): string[] {
  const own = metadataKeywords(video.title);
  const frequency = new Map<string, number>();
  for (const item of allVideos.slice(0, 100)) for (const keyword of metadataKeywords(item.title)) frequency.set(keyword, (frequency.get(keyword) ?? 0) + 1);
  const recurring = [...frequency.entries()].filter(([, count]) => count >= 2).sort((a, b) => b[1] - a[1]).map(([keyword]) => keyword);
  const existing = new Set((video.tags ?? []).map((tag) => tag.toLowerCase()));
  return [...new Set([...own, ...recurring])].filter((tag) => !existing.has(tag.toLowerCase())).slice(0, 10);
}
