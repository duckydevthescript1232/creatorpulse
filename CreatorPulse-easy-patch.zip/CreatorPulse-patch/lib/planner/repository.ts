import { and, asc, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { plannerItems } from "@/db/schema";
import type { PlannerItem, PlannerStatus, VideoFormat } from "@/lib/domain/types";

export type PlannerItemInput = { workingTitle: string; topic: string; targetDate?: string | null; format: VideoFormat; notes?: string; status?: PlannerStatus; tags?: string[]; thumbnailIdea?: string };

function toDomain(row: typeof plannerItems.$inferSelect): PlannerItem {
  return { id: row.id, workingTitle: row.workingTitle, topic: row.topic, targetDate: row.targetDate?.toISOString().slice(0, 10) ?? null, format: row.format, notes: row.notes, status: row.status, tags: row.tags, thumbnailIdea: row.thumbnailIdea, position: row.position };
}

export async function listPlannerItems(userId: string, channelId: string): Promise<PlannerItem[]> {
  const rows = await getDb().select().from(plannerItems).where(and(eq(plannerItems.userId, userId), eq(plannerItems.channelId, channelId))).orderBy(asc(plannerItems.position), asc(plannerItems.createdAt));
  return rows.map(toDomain);
}

export async function createPlannerItem(userId: string, channelId: string, input: PlannerItemInput): Promise<PlannerItem> {
  const existing = await listPlannerItems(userId, channelId); const now = new Date(); const id = crypto.randomUUID();
  await getDb().insert(plannerItems).values({ id, userId, channelId, workingTitle: input.workingTitle, topic: input.topic, targetDate: input.targetDate ? new Date(input.targetDate) : null, format: input.format, notes: input.notes ?? "", status: input.status ?? "idea", tags: input.tags ?? [], thumbnailIdea: input.thumbnailIdea ?? "", position: existing.length, createdAt: now, updatedAt: now });
  return { id, workingTitle: input.workingTitle, topic: input.topic, targetDate: input.targetDate ?? null, format: input.format, notes: input.notes ?? "", status: input.status ?? "idea", tags: input.tags ?? [], thumbnailIdea: input.thumbnailIdea ?? "", position: existing.length };
}

export async function updatePlannerItem(userId: string, id: string, input: Partial<PlannerItemInput> & { position?: number }): Promise<boolean> {
  const changes = { ...(input.workingTitle !== undefined ? { workingTitle: input.workingTitle } : {}), ...(input.topic !== undefined ? { topic: input.topic } : {}), ...(input.targetDate !== undefined ? { targetDate: input.targetDate ? new Date(input.targetDate) : null } : {}), ...(input.format !== undefined ? { format: input.format } : {}), ...(input.notes !== undefined ? { notes: input.notes } : {}), ...(input.status !== undefined ? { status: input.status } : {}), ...(input.tags !== undefined ? { tags: input.tags } : {}), ...(input.thumbnailIdea !== undefined ? { thumbnailIdea: input.thumbnailIdea } : {}), ...(input.position !== undefined ? { position: input.position } : {}), updatedAt: new Date() };
  const result = await getDb().update(plannerItems).set(changes).where(and(eq(plannerItems.id, id), eq(plannerItems.userId, userId))).returning({ id: plannerItems.id });
  return result.length > 0;
}

export async function deletePlannerItem(userId: string, id: string): Promise<boolean> {
  const result = await getDb().delete(plannerItems).where(and(eq(plannerItems.id, id), eq(plannerItems.userId, userId))).returning({ id: plannerItems.id });
  return result.length > 0;
}

export async function reorderPlannerItems(userId: string, ids: string[]): Promise<boolean> {
  const owned = await getDb().select({ id: plannerItems.id }).from(plannerItems).where(eq(plannerItems.userId, userId));
  const ownedIds = new Set(owned.map((row) => row.id));
  if (ids.some((id) => !ownedIds.has(id))) return false;
  for (const [position, id] of ids.entries()) await getDb().update(plannerItems).set({ position, updatedAt: new Date() }).where(and(eq(plannerItems.id, id), eq(plannerItems.userId, userId)));
  return true;
}
