import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { users } from "@/db/schema";
import type { AuthenticatedViewer } from "@/lib/auth/viewer";
import { getActiveChannelSource, getConnectionSummary, getDeepMetricsSummary, getLatestStudioImport, getPublicChannelVideos } from "@/lib/youtube/public-repository";
import { getLatestChannelSnapshot } from "@/lib/youtube/repository";
import { isCreatorPulseOwner } from "@/lib/entitlements/owner";


export async function getWorkspaceShell(viewer: AuthenticatedViewer) {
  const [source, userRows, connection] = await Promise.all([
    getActiveChannelSource(viewer.id),
    getDb().select({ plan: users.plan }).from(users).where(eq(users.id, viewer.id)).limit(1),
    getConnectionSummary(viewer.id),
  ]);
  const owner = isCreatorPulseOwner(viewer.id);
  const plan = owner ? "creator_plus" as const : userRows[0]?.plan ?? "free" as const;
  const viewerShell = { name: viewer.name, label: owner ? "Owner · Creator+ access" : `${plan === "creator_plus" ? "Creator+" : plan === "pro" ? "Pro" : "Free"} plan`, signedIn: true, role: viewer.role };
  if (!source) return { channel: { name: "CreatorPulse", label: "No channel selected", connected: false, hasSource: false }, viewer: viewerShell };
  return {
    channel: {
      name: source.channelTitle,
      label: source.channelHandle ?? "YouTube channel",
      avatarUrl: source.channelAvatarUrl,
      connected: source.sourceType === "oauth" && Boolean(connection),
      hasSource: true,
      syncLabel: connection?.lastSyncedAt ? `Last synced ${connection.lastSyncedAt.toLocaleString("en-US")}` : `Scanned ${source.lastSyncedAt.toLocaleString("en-US")}`,
    },
    viewer: viewerShell,
  };
}

export async function getWorkspace(viewer: AuthenticatedViewer, options: { videoLimit?: number } = {}) {
  const [source, userRows, connection] = await Promise.all([
    getActiveChannelSource(viewer.id),
    getDb().select({ plan: users.plan }).from(users).where(eq(users.id, viewer.id)).limit(1),
    getConnectionSummary(viewer.id),
  ]);
  const user = userRows[0] ?? null;
  const owner = isCreatorPulseOwner(viewer.id);
  const plan = owner ? "creator_plus" as const : user?.plan ?? "free" as const;
  if (!source) return { viewer, source: null, videos: [], latestImport: null, deep: null, snapshot: null, connection, plan, owner };
  const [videos, latestImport, deep, snapshot] = await Promise.all([
    getPublicChannelVideos(viewer.id, source.channelId, options.videoLimit ?? 60),
    getLatestStudioImport(viewer.id, source.channelId),
    getDeepMetricsSummary(viewer.id, source.channelId),
    getLatestChannelSnapshot(viewer.id, source.channelId),
  ]);
  return { viewer, source, videos, latestImport, deep, snapshot, connection, plan, owner };
}

export function workspaceShell(workspace: Awaited<ReturnType<typeof getWorkspace>>) {
  if (!workspace.source) return { channel: { name: "CreatorPulse", label: "No channel selected", connected: false, hasSource: false }, viewer: { name: workspace.viewer.name, label: workspace.owner ? "Owner · Creator+ access" : workspace.viewer.email, signedIn: true, role: workspace.viewer.role } };
  return {
    channel: { name: workspace.source.channelTitle, label: workspace.source.channelHandle ?? "Public channel", avatarUrl: workspace.source.channelAvatarUrl, connected: workspace.source.sourceType === "oauth" && Boolean(workspace.connection), hasSource: true, syncLabel: workspace.connection?.lastSyncedAt ? `Last synced ${workspace.connection.lastSyncedAt.toLocaleString("en-US")}` : `Scanned ${workspace.source.lastSyncedAt.toLocaleString("en-US")}` },
    viewer: { name: workspace.viewer.name, label: workspace.owner ? "Owner · Creator+ access" : `${workspace.plan === "creator_plus" ? "Creator+" : workspace.plan === "pro" ? "Pro" : "Free"} plan`, signedIn: true, role: workspace.viewer.role },
  };
}
