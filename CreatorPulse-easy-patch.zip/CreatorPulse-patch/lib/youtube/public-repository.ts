import { and, desc, eq, isNull } from "drizzle-orm";
import { getDb } from "@/db";
import { channelSnapshots, channelSources, plannerItems, studioImports, users, videoSnapshots, videos, youtubeConnections } from "@/db/schema";
import type { AuthenticatedViewer } from "@/lib/auth/viewer";
import type { VideoRecord } from "@/lib/domain/types";
import type { PublicChannelResult } from "./public-source";

function localVideoId(userId: string, youtubeVideoId: string): string {
  return `${userId}:${youtubeVideoId}`;
}

export async function upsertPublicChannel(viewer: AuthenticatedViewer, result: PublicChannelResult): Promise<void> {
  const db = getDb(); const now = new Date(); const profile = result.profile;
  await db.insert(users).values({ id: viewer.id, email: viewer.email, name: viewer.name, createdAt: now, updatedAt: now }).onConflictDoUpdate({ target: users.id, set: { email: viewer.email, name: viewer.name, updatedAt: now } });
  await db.insert(channelSources).values({ id: crypto.randomUUID(), userId: viewer.id, channelId: profile.channelId, channelTitle: profile.title, channelHandle: profile.handle, channelAvatarUrl: profile.avatarUrl, canonicalUrl: profile.canonicalUrl, sourceType: "public", publicSubscribers: profile.subscribers, publicTotalViews: profile.totalViews, publicUploadCount: profile.uploadCount, lastSyncedAt: now, syncStatus: result.warnings.length ? "partial" : "ready", lastSyncError: result.warnings.join(" ") || null, createdAt: now, updatedAt: now }).onConflictDoUpdate({ target: [channelSources.userId, channelSources.channelId], set: { channelTitle: profile.title, channelHandle: profile.handle, channelAvatarUrl: profile.avatarUrl, canonicalUrl: profile.canonicalUrl, publicSubscribers: profile.subscribers, publicTotalViews: profile.totalViews, publicUploadCount: profile.uploadCount, lastSyncedAt: now, syncStatus: result.warnings.length ? "partial" : "ready", lastSyncError: result.warnings.join(" ") || null, updatedAt: now } });
  await db.insert(channelSnapshots).values({ id: crypto.randomUUID(), userId: viewer.id, channelId: profile.channelId, capturedAt: now, subscribers: profile.subscribers, views: profile.totalViews ?? result.videos.reduce((sum, video) => sum + video.views, 0), uploads: profile.uploadCount ?? result.videos.length, availableMetrics: ["publicChannel", "recentUploads", ...(profile.subscribers !== null ? ["publicSubscribers"] : [])], periodMetrics: {} });
  for (const record of result.videos) await upsertPublicVideo(viewer.id, profile.channelId, record, now);
}

async function upsertPublicVideo(userId: string, channelId: string, record: VideoRecord, capturedAt: Date): Promise<void> {
  const db = getDb(); const id = localVideoId(userId, record.id);
  await db.insert(videos).values({ id, youtubeVideoId: record.id, userId, channelId, title: record.title, publishedAt: new Date(record.publishedAt), durationSeconds: record.durationSeconds, format: record.format, topic: record.topic, createdAt: capturedAt, updatedAt: capturedAt }).onConflictDoUpdate({ target: videos.id, set: { youtubeVideoId: record.id, title: record.title, publishedAt: new Date(record.publishedAt), durationSeconds: record.durationSeconds, format: record.format, updatedAt: capturedAt } });
  await db.insert(videoSnapshots).values({ id: crypto.randomUUID(), userId, videoId: id, capturedAt, views: record.views, likes: record.likes ?? null, comments: record.comments ?? null, watchMinutes: null, subscribersGained: record.subscribersGained ?? null, impressions: null, impressionsCtr: null, averageViewDurationSeconds: null, averagePercentageViewed: null });
}

export async function getActiveChannelSource(userId: string) {
  return (await getDb().select().from(channelSources).where(eq(channelSources.userId, userId)).orderBy(desc(channelSources.updatedAt)).limit(1))[0] ?? null;
}

export async function getPublicChannelVideos(userId: string, channelId: string, limit = 15): Promise<VideoRecord[]> {
  const rows = await getDb().select({ video: videos, snapshot: videoSnapshots }).from(videos).leftJoin(videoSnapshots, eq(videos.id, videoSnapshots.videoId)).where(and(eq(videos.userId, userId), eq(videos.channelId, channelId))).orderBy(desc(videos.publishedAt), desc(videoSnapshots.capturedAt)).limit(limit * 4);
  const unique = new Map<string, VideoRecord>();
  for (const { video, snapshot } of rows) if (!unique.has(video.id)) unique.set(video.id, { id: video.youtubeVideoId ?? video.id, title: video.title, description: video.description ?? undefined, tags: video.tags ?? undefined, categoryId: video.categoryId ?? undefined, privacyStatus: video.privacyStatus ?? undefined, thumbnailUrl: video.thumbnailUrl ?? undefined, defaultLanguage: video.defaultLanguage ?? undefined, defaultAudioLanguage: video.defaultAudioLanguage ?? undefined, metadataSyncedAt: video.metadataSyncedAt?.toISOString(), publishedAt: video.publishedAt.toISOString(), durationSeconds: video.durationSeconds, format: video.format, topic: video.topic ?? "Unclassified", views: snapshot?.views ?? 0, likes: snapshot?.likes ?? undefined, comments: snapshot?.comments ?? undefined, subscribersGained: snapshot?.subscribersGained ?? undefined });
  return [...unique.values()].slice(0, limit);
}

export async function upsertOAuthChannelSource(userId: string, channel: { id: string; title: string; handle: string | null; avatarUrl: string | null; subscribers: number | null; totalViews: number; uploadCount: number }, syncStatus: "ready" | "partial" | "error", lastSyncError: string | null): Promise<void> {
  const db = getDb(); const now = new Date();
  await db.insert(channelSources).values({ id: crypto.randomUUID(), userId, channelId: channel.id, channelTitle: channel.title, channelHandle: channel.handle, channelAvatarUrl: channel.avatarUrl, canonicalUrl: `https://www.youtube.com/channel/${channel.id}`, sourceType: "oauth", publicSubscribers: channel.subscribers, publicTotalViews: channel.totalViews, publicUploadCount: channel.uploadCount, lastSyncedAt: now, syncStatus, lastSyncError, createdAt: now, updatedAt: now }).onConflictDoUpdate({ target: [channelSources.userId, channelSources.channelId], set: { channelTitle: channel.title, channelHandle: channel.handle, channelAvatarUrl: channel.avatarUrl, sourceType: "oauth", publicSubscribers: channel.subscribers, publicTotalViews: channel.totalViews, publicUploadCount: channel.uploadCount, lastSyncedAt: now, syncStatus, lastSyncError, updatedAt: now } });
}

export async function getConnectionSummary(userId: string) {
  const row = (await getDb().select({ channelId: youtubeConnections.channelId, channelTitle: youtubeConnections.channelTitle, scopes: youtubeConnections.scopes, expiresAt: youtubeConnections.expiresAt, lastSyncedAt: youtubeConnections.lastSyncedAt, syncStatus: youtubeConnections.syncStatus, lastSyncError: youtubeConnections.lastSyncError }).from(youtubeConnections).where(and(eq(youtubeConnections.userId, userId), isNull(youtubeConnections.disconnectedAt))).orderBy(desc(youtubeConnections.updatedAt)).limit(1))[0];
  return row ?? null;
}

export async function saveStudioImport(input: { viewer: AuthenticatedViewer; channelId: string; fileName: string; rows: Array<{ video: VideoRecord; watchMinutes?: number; impressions?: number; impressionsCtrBasisPoints?: number; averageViewDurationSeconds?: number; averagePercentageViewedBasisPoints?: number }>; skippedRows: number; metricCoverage: string[] }): Promise<void> {
  const db = getDb(); const now = new Date();
  for (const row of input.rows) {
    const id = localVideoId(input.viewer.id, row.video.id); const hasPublishedAt = row.video.publishedAt !== new Date(0).toISOString();
    await db.insert(videos).values({ id, youtubeVideoId: row.video.id, userId: input.viewer.id, channelId: input.channelId, title: row.video.title, publishedAt: new Date(row.video.publishedAt), durationSeconds: row.video.durationSeconds, format: row.video.format, topic: row.video.topic, createdAt: now, updatedAt: now }).onConflictDoUpdate({ target: videos.id, set: { youtubeVideoId: row.video.id, title: row.video.title, ...(hasPublishedAt ? { publishedAt: new Date(row.video.publishedAt) } : {}), ...(row.video.durationSeconds > 0 ? { durationSeconds: row.video.durationSeconds, format: row.video.format } : {}), updatedAt: now } });
    await db.insert(videoSnapshots).values({ id: crypto.randomUUID(), userId: input.viewer.id, videoId: id, capturedAt: now, views: row.video.views, likes: row.video.likes ?? null, comments: row.video.comments ?? null, watchMinutes: row.watchMinutes ?? null, subscribersGained: row.video.subscribersGained ?? null, impressions: row.impressions ?? null, impressionsCtr: row.impressionsCtrBasisPoints ?? null, averageViewDurationSeconds: row.averageViewDurationSeconds ?? null, averagePercentageViewed: row.averagePercentageViewedBasisPoints ?? null });
  }
  await db.insert(studioImports).values({ id: crypto.randomUUID(), userId: input.viewer.id, channelId: input.channelId, fileName: input.fileName, importedRows: input.rows.length, skippedRows: input.skippedRows, metricCoverage: input.metricCoverage, importedAt: now });
}

export async function getLatestStudioImport(userId: string, channelId: string) {
  return (await getDb().select().from(studioImports).where(and(eq(studioImports.userId, userId), eq(studioImports.channelId, channelId))).orderBy(desc(studioImports.importedAt)).limit(1))[0] ?? null;
}

export async function getDeepMetricsSummary(userId: string, channelId: string) {
  const rows = await getDb().select({ videoId: videos.id, snapshot: videoSnapshots }).from(videos).leftJoin(videoSnapshots, eq(videos.id, videoSnapshots.videoId)).where(and(eq(videos.userId, userId), eq(videos.channelId, channelId))).orderBy(desc(videoSnapshots.capturedAt)).limit(200);
  const latest = new Map<string, NonNullable<(typeof rows)[number]["snapshot"]>>();
  for (const row of rows) if (row.snapshot && !latest.has(row.videoId)) latest.set(row.videoId, row.snapshot);
  const values = [...latest.values()];
  const impressions = values.reduce((sum, item) => sum + (item.impressions ?? 0), 0);
  const watchMinutes = values.reduce((sum, item) => sum + (item.watchMinutes ?? 0), 0);
  const ctrValues = values.filter((item) => item.impressionsCtr !== null).map((item) => item.impressionsCtr!);
  const retentionValues = values.filter((item) => item.averagePercentageViewed !== null).map((item) => item.averagePercentageViewed!);
  return { impressions, watchMinutes, averageCtr: ctrValues.length ? ctrValues.reduce((sum, value) => sum + value, 0) / ctrValues.length / 100 : null, averagePercentageViewed: retentionValues.length ? retentionValues.reduce((sum, value) => sum + value, 0) / retentionValues.length / 100 : null };
}

export async function removeChannelWorkspace(userId: string, channelId: string): Promise<void> {
  const db = getDb();
  await db.delete(youtubeConnections).where(and(eq(youtubeConnections.userId, userId), eq(youtubeConnections.channelId, channelId)));
  await db.delete(studioImports).where(and(eq(studioImports.userId, userId), eq(studioImports.channelId, channelId)));
  await db.delete(plannerItems).where(and(eq(plannerItems.userId, userId), eq(plannerItems.channelId, channelId)));
  await db.delete(channelSnapshots).where(and(eq(channelSnapshots.userId, userId), eq(channelSnapshots.channelId, channelId)));
  // videoSnapshots cascade from videos; deleting the channel video rows clears their stored metric history too.
  await db.delete(videos).where(and(eq(videos.userId, userId), eq(videos.channelId, channelId)));
  await db.delete(channelSources).where(and(eq(channelSources.userId, userId), eq(channelSources.channelId, channelId)));
  const account = (await db.select({ youtubeChannelId: users.youtubeChannelId }).from(users).where(eq(users.id, userId)).limit(1))[0];
  if (account?.youtubeChannelId === channelId) await db.update(users).set({ youtubeChannelId: null, youtubeHandle: null, updatedAt: new Date() }).where(eq(users.id, userId));
}
