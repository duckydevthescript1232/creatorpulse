import { and, desc, eq, isNull } from "drizzle-orm";
import { getDb } from "@/db";
import { channelSnapshots, users, videoSnapshots, videos, youtubeConnections } from "@/db/schema";
import type { AuthenticatedViewer } from "@/lib/auth/viewer";
import type { VideoRecord } from "@/lib/domain/types";

export type PeriodMetrics = {
  views28d?: number;
  viewsPrevious28d?: number;
  watchMinutes28d?: number;
  subscribersGained28d?: number;
  subscribersLost28d?: number;
  dailyViews?: Array<{ label: string; value: number }>;
};

export type ConnectionInput = {
  channelId: string;
  channelTitle: string;
  channelHandle: string | null;
  channelAvatarUrl: string | null;
  uploadsPlaylistId: string | null;
  encryptedAccessToken: string;
  encryptedRefreshToken: string | null;
  scopes: string[];
  expiresAt: Date;
  syncStatus: "ready" | "partial" | "error";
  lastSyncError: string | null;
};

export type ChannelSnapshotInput = {
  channelId: string;
  subscribers: number | null;
  views: number;
  uploads: number;
  availableMetrics: string[];
  periodMetrics: PeriodMetrics;
};

export async function upsertViewer(viewer: AuthenticatedViewer): Promise<void> {
  const now = new Date();
  await getDb().insert(users).values({ id: viewer.id, email: viewer.email, name: viewer.name, createdAt: now, updatedAt: now }).onConflictDoUpdate({ target: users.id, set: { email: viewer.email, name: viewer.name, updatedAt: now } });
}

export async function saveConnection(viewer: AuthenticatedViewer, input: ConnectionInput): Promise<void> {
  await upsertViewer(viewer);
  const now = new Date();
  await getDb().insert(youtubeConnections).values({
    id: crypto.randomUUID(), userId: viewer.id, ...input, disconnectedAt: null, lastSyncedAt: now, createdAt: now, updatedAt: now,
  }).onConflictDoUpdate({ target: [youtubeConnections.userId, youtubeConnections.channelId], set: { ...input, disconnectedAt: null, lastSyncedAt: now, updatedAt: now } });
}

export async function saveSnapshot(userId: string, input: ChannelSnapshotInput): Promise<void> {
  await getDb().insert(channelSnapshots).values({ id: crypto.randomUUID(), userId, capturedAt: new Date(), ...input });
}

export async function saveVideos(userId: string, channelId: string, records: VideoRecord[]): Promise<void> {
  const db = getDb();
  const now = new Date();
  const saveOne = async (record: VideoRecord) => {
    const id = `${userId}:${record.id}`;
    const metadata = { title: record.title, description: record.description ?? null, tags: record.tags ?? null, categoryId: record.categoryId ?? null, privacyStatus: record.privacyStatus ?? null, thumbnailUrl: record.thumbnailUrl ?? null, defaultLanguage: record.defaultLanguage ?? null, defaultAudioLanguage: record.defaultAudioLanguage ?? null, metadataSyncedAt: record.metadataSyncedAt ? new Date(record.metadataSyncedAt) : now };
    await db.insert(videos).values({ id, youtubeVideoId: record.id, userId, channelId, ...metadata, publishedAt: new Date(record.publishedAt), durationSeconds: record.durationSeconds, format: record.format, topic: null, createdAt: now, updatedAt: now }).onConflictDoUpdate({ target: videos.id, set: { youtubeVideoId: record.id, ...metadata, durationSeconds: record.durationSeconds, format: record.format, updatedAt: now } });
    await db.insert(videoSnapshots).values({ id: crypto.randomUUID(), userId, videoId: id, capturedAt: now, views: record.views, likes: record.likes ?? null, comments: record.comments ?? null, watchMinutes: null, subscribersGained: record.subscribersGained ?? null });
  };
  for (let index = 0; index < records.length; index += 10) await Promise.all(records.slice(index, index + 10).map(saveOne));
}

export async function getActiveConnection(userId: string) {
  return (await getDb().select().from(youtubeConnections).where(and(eq(youtubeConnections.userId, userId), isNull(youtubeConnections.disconnectedAt))).orderBy(desc(youtubeConnections.updatedAt)).limit(1))[0] ?? null;
}

export async function getLatestChannelSnapshot(userId: string, channelId: string) {
  return (await getDb().select().from(channelSnapshots).where(and(eq(channelSnapshots.userId, userId), eq(channelSnapshots.channelId, channelId))).orderBy(desc(channelSnapshots.capturedAt)).limit(1))[0] ?? null;
}

export async function getRecentVideos(userId: string, channelId: string, limit = 10): Promise<VideoRecord[]> {
  const rows = await getDb().select({ video: videos, snapshot: videoSnapshots }).from(videos).leftJoin(videoSnapshots, eq(videos.id, videoSnapshots.videoId)).where(and(eq(videos.userId, userId), eq(videos.channelId, channelId))).orderBy(desc(videos.publishedAt), desc(videoSnapshots.capturedAt)).limit(limit * 3);
  const unique = new Map<string, VideoRecord>();
  for (const { video, snapshot } of rows) if (!unique.has(video.id)) unique.set(video.id, { id: video.youtubeVideoId ?? video.id, title: video.title, description: video.description ?? undefined, tags: video.tags ?? undefined, categoryId: video.categoryId ?? undefined, privacyStatus: video.privacyStatus ?? undefined, thumbnailUrl: video.thumbnailUrl ?? undefined, defaultLanguage: video.defaultLanguage ?? undefined, defaultAudioLanguage: video.defaultAudioLanguage ?? undefined, metadataSyncedAt: video.metadataSyncedAt?.toISOString(), publishedAt: video.publishedAt.toISOString(), durationSeconds: video.durationSeconds, format: video.format, topic: video.topic ?? "Unclassified", views: snapshot?.views ?? 0, likes: snapshot?.likes ?? undefined, comments: snapshot?.comments ?? undefined, subscribersGained: snapshot?.subscribersGained ?? undefined });
  return [...unique.values()].slice(0, limit);
}

export async function updateConnectionTokens(userId: string, channelId: string, values: { encryptedAccessToken: string; encryptedRefreshToken?: string | null; expiresAt: Date }): Promise<void> {
  await getDb().update(youtubeConnections).set({ ...values, updatedAt: new Date() }).where(and(eq(youtubeConnections.userId, userId), eq(youtubeConnections.channelId, channelId)));
}

export async function updateConnectionStatus(userId: string, channelId: string, syncStatus: "ready" | "partial" | "error", lastSyncError: string | null): Promise<void> {
  await getDb().update(youtubeConnections).set({ syncStatus, lastSyncError, lastSyncedAt: new Date(), updatedAt: new Date() }).where(and(eq(youtubeConnections.userId, userId), eq(youtubeConnections.channelId, channelId)));
}

export async function saveVideoMetadata(userId: string, channelId: string, videoId: string, metadata: { title: string; description: string; tags: string[]; categoryId: string | null; defaultLanguage: string | null; defaultAudioLanguage: string | null }): Promise<void> {
  await getDb().update(videos).set({ title: metadata.title, description: metadata.description, tags: metadata.tags, categoryId: metadata.categoryId, defaultLanguage: metadata.defaultLanguage, defaultAudioLanguage: metadata.defaultAudioLanguage, metadataSyncedAt: new Date(), updatedAt: new Date() }).where(and(eq(videos.userId, userId), eq(videos.channelId, channelId), eq(videos.youtubeVideoId, videoId)));
}

export async function disconnectChannel(userId: string, channelId: string): Promise<void> {
  await getDb().delete(youtubeConnections).where(and(eq(youtubeConnections.userId, userId), eq(youtubeConnections.channelId, channelId)));
}
