import type { VideoRecord } from "@/lib/domain/types";
import { detectFormat, parseIsoDurationSeconds } from "./transform";
import type { PeriodMetrics } from "./repository";

type ChannelResource = {
  id: string;
  snippet?: { title?: string; customUrl?: string; thumbnails?: { default?: { url?: string }; medium?: { url?: string } } };
  contentDetails?: { relatedPlaylists?: { uploads?: string } };
  statistics?: { subscriberCount?: string; hiddenSubscriberCount?: boolean; viewCount?: string; videoCount?: string };
};

type VideoResource = {
  id: string;
  snippet?: { title?: string; description?: string; tags?: string[]; categoryId?: string; publishedAt?: string; liveBroadcastContent?: string; defaultLanguage?: string; defaultAudioLanguage?: string; thumbnails?: { high?: { url?: string }; medium?: { url?: string }; default?: { url?: string } } };
  contentDetails?: { duration?: string };
  statistics?: { viewCount?: string; likeCount?: string; commentCount?: string };
  status?: { privacyStatus?: string };
};

const MAX_SYNCED_VIDEOS = 500;
const PLAYLIST_PAGE_SIZE = 50;
const VIDEOS_BATCH_SIZE = 50;

async function googleGet<T>(url: URL, accessToken: string): Promise<T> {
  const response = await fetch(url, { headers: { authorization: `Bearer ${accessToken}` } });
  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(`Google API request failed with status ${response.status}${detail ? `: ${detail.slice(0, 180)}` : "."}`);
  }
  return response.json() as Promise<T>;
}

function integer(value: string | undefined): number { return Number.parseInt(value ?? "0", 10) || 0; }
function chunks<T>(items: T[], size: number): T[][] { const result: T[][] = []; for (let index = 0; index < items.length; index += size) result.push(items.slice(index, index + size)); return result; }

export async function fetchOwnedChannel(accessToken: string): Promise<ChannelResource> {
  const url = new URL("https://www.googleapis.com/youtube/v3/channels");
  url.search = new URLSearchParams({ part: "snippet,contentDetails,statistics", mine: "true" }).toString();
  const result = await googleGet<{ items?: ChannelResource[] }>(url, accessToken);
  const channel = result.items?.[0];
  if (!channel) throw new Error("No YouTube channel is associated with this Google account.");
  return channel;
}

async function fetchUploadVideoIds(accessToken: string, uploadsPlaylistId: string): Promise<{ ids: string[]; truncated: boolean }> {
  const ids: string[] = [];
  let pageToken: string | undefined;
  let truncated = false;

  do {
    const url = new URL("https://www.googleapis.com/youtube/v3/playlistItems");
    const params = new URLSearchParams({ part: "contentDetails", playlistId: uploadsPlaylistId, maxResults: String(PLAYLIST_PAGE_SIZE) });
    if (pageToken) params.set("pageToken", pageToken);
    url.search = params.toString();
    const result = await googleGet<{ items?: Array<{ contentDetails?: { videoId?: string } }>; nextPageToken?: string }>(url, accessToken);
    ids.push(...(result.items ?? []).map((item) => item.contentDetails?.videoId).filter((id): id is string => Boolean(id)));
    pageToken = result.nextPageToken;
    if (ids.length >= MAX_SYNCED_VIDEOS) {
      truncated = Boolean(pageToken) || ids.length > MAX_SYNCED_VIDEOS;
      break;
    }
  } while (pageToken);

  return { ids: ids.slice(0, MAX_SYNCED_VIDEOS), truncated };
}

async function fetchVideoBatch(accessToken: string, ids: string[]): Promise<VideoResource[]> {
  if (!ids.length) return [];
  const url = new URL("https://www.googleapis.com/youtube/v3/videos");
  url.search = new URLSearchParams({ part: "snippet,contentDetails,statistics,status", id: ids.join(",") }).toString();
  const result = await googleGet<{ items?: VideoResource[] }>(url, accessToken);
  return result.items ?? [];
}

async function fetchVideoRecords(accessToken: string, ids: string[]): Promise<VideoRecord[]> {
  if (ids.length === 0) return [];
  const batches = chunks(ids, VIDEOS_BATCH_SIZE);
  const resources = (await Promise.all(batches.map((batch) => fetchVideoBatch(accessToken, batch)))).flat();
  const byId = new Map(resources.map((video) => [video.id, video]));
  return ids.flatMap((id) => {
    const video = byId.get(id);
    if (!video?.snippet?.title || !video.snippet.publishedAt || !video.contentDetails?.duration) return [];
    const durationSeconds = parseIsoDurationSeconds(video.contentDetails.duration);
    return [{
      id: video.id,
      title: video.snippet.title,
      description: video.snippet.description ?? "",
      tags: video.snippet.tags ?? [],
      categoryId: video.snippet.categoryId,
      privacyStatus: video.status?.privacyStatus,
      thumbnailUrl: video.snippet.thumbnails?.high?.url ?? video.snippet.thumbnails?.medium?.url ?? video.snippet.thumbnails?.default?.url,
      defaultLanguage: video.snippet.defaultLanguage,
      defaultAudioLanguage: video.snippet.defaultAudioLanguage,
      metadataSyncedAt: new Date().toISOString(),
      publishedAt: video.snippet.publishedAt,
      durationSeconds,
      format: detectFormat(durationSeconds, video.snippet.liveBroadcastContent === "live"),
      topic: "Unclassified",
      views: integer(video.statistics?.viewCount),
      likes: video.statistics?.likeCount ? integer(video.statistics.likeCount) : undefined,
      comments: video.statistics?.commentCount ? integer(video.statistics.commentCount) : undefined,
    }];
  });
}

function isoDate(date: Date): string { return date.toISOString().slice(0, 10); }

async function fetchPeriodMetrics(accessToken: string): Promise<PeriodMetrics> {
  const end = new Date();
  end.setUTCHours(0, 0, 0, 0);
  end.setUTCDate(end.getUTCDate() - 1);
  const start = new Date(end);
  start.setUTCDate(start.getUTCDate() - 364);
  const url = new URL("https://youtubeanalytics.googleapis.com/v2/reports");
  url.search = new URLSearchParams({ ids: "channel==MINE", startDate: isoDate(start), endDate: isoDate(end), metrics: "views,estimatedMinutesWatched,subscribersGained,subscribersLost", dimensions: "day", sort: "day" }).toString();
  const result = await googleGet<{ rows?: Array<[string, number, number, number, number]> }>(url, accessToken);
  const rows = result.rows ?? [];
  const current = rows.slice(-28);
  const previous = rows.slice(-56, -28);
  const sum = (items: typeof rows, index: 1 | 2 | 3 | 4) => items.reduce((total, row) => total + Number(row[index] ?? 0), 0);
  return {
    views28d: sum(current, 1),
    viewsPrevious28d: sum(previous, 1),
    watchMinutes28d: sum(current, 2),
    subscribersGained28d: sum(current, 3),
    subscribersLost28d: sum(current, 4),
    dailyViews: rows.map((row) => ({ label: row[0], value: Number(row[1] ?? 0) })),
  };
}

export async function synchronizeYouTube(accessToken: string) {
  const channel = await fetchOwnedChannel(accessToken);
  const uploadsPlaylistId = channel.contentDetails?.relatedPlaylists?.uploads ?? null;
  const uploadIds = uploadsPlaylistId ? await fetchUploadVideoIds(accessToken, uploadsPlaylistId) : { ids: [], truncated: false };
  const recentVideos = await fetchVideoRecords(accessToken, uploadIds.ids);
  let periodMetrics: PeriodMetrics = {};
  let analyticsError: string | null = null;
  try { periodMetrics = await fetchPeriodMetrics(accessToken); } catch (error) { analyticsError = error instanceof Error ? error.message : "YouTube Analytics is temporarily unavailable."; }
  return {
    channel: {
      id: channel.id,
      title: channel.snippet?.title ?? "YouTube channel",
      handle: channel.snippet?.customUrl ?? null,
      avatarUrl: channel.snippet?.thumbnails?.medium?.url ?? channel.snippet?.thumbnails?.default?.url ?? null,
      uploadsPlaylistId,
      subscribers: channel.statistics?.hiddenSubscriberCount ? null : integer(channel.statistics?.subscriberCount),
      totalViews: integer(channel.statistics?.viewCount),
      uploadCount: integer(channel.statistics?.videoCount),
    },
    recentVideos,
    videoSyncTruncated: uploadIds.truncated,
    periodMetrics,
    analyticsError,
  };
}
