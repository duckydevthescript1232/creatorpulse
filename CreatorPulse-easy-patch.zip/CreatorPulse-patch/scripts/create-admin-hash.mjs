import { hashPassword } from "../lib/auth/password.ts";

async function readHidden(prompt) {
  if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== "function") {
    throw new Error("Run this command in an interactive terminal so the password can stay hidden.");
  }
  process.stdout.write(prompt);
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.setEncoding("utf8");
  let value = "";
  try {
    for await (const chunk of process.stdin) {
      for (const char of chunk) {
        if (char === "\u0003") throw new Error("Cancelled.");
        if (char === "\r" || char === "\n") {
          process.stdout.write("\n");
          return value;
        }
        if (char === "\u007f" || char === "\b") {
          if (value.length) value = value.slice(0, -1);
          continue;
        }
        if (char >= " ") value += char;
      }
    }
  } finally {
    process.stdin.setRawMode(false);
    process.stdin.pause();
  }
  return value;
}

try {
  const first = await readHidden("Admin password: ");
  if (first.length < 12) throw new Error("Use a password of at least 12 characters.");
  const second = await readHidden("Confirm password: ");
  if (first !== second) throw new Error("Passwords did not match.");
  console.log("\nSet this value as CREATORPULSE_ADMIN_PASSWORD_HASH:\n");
  console.log(await hashPassword(first));
  console.log("\nThe raw password was not written to a file.");
} catch (error) {
  process.stderr.write(`${error instanceof Error ? error.message : "Could not create a password hash."}\n`);
  process.exitCode = 1;
}
