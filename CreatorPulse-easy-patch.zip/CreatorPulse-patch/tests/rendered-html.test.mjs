import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("marketing source points creators into the real authenticated channel flow", async () => {
  const source = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  assert.match(source, /Stop guessing what to/);
  assert.match(source, /CreatorPulse/);
  assert.match(source, /\/login\?returnTo=\/channel-setup/);
  assert.doesNotMatch(source, /action=["']\/api\/channel\/analyze["']/);
  assert.doesNotMatch(source, /Demo Channel/);
  assert.doesNotMatch(source, /codex-preview|react-loading-skeleton/i);
});

test("workspace navigation keeps a persistent shell and responds before route data", async () => {
  const [hardLink, shell, layout] = await Promise.all([
    readFile(new URL("../components/HardLink.tsx", import.meta.url), "utf8"),
    readFile(new URL("../components/app/DashboardShell.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/layout.tsx", import.meta.url), "utf8"),
  ]);
  assert.match(hardLink, /next\/link/);
  assert.match(hardLink, /prefetch=\{prefetch\}/);
  assert.doesNotMatch(hardLink, /prefetch \?\? false/);
  assert.match(shell, /router\.prefetch/);
  assert.match(shell, /route-progress/);
  assert.match(shell, /setTimeout\(\(\) => setPendingRoute\(null\), 5000\)/);
  assert.match(shell, /pending \? <>.*RouteSkeleton/s);
  assert.match(layout, /getAuthenticatedViewer/);
  assert.match(layout, /getWorkspaceShell/);
  assert.match(layout, /<AppFrame/);
});

test("client workspaces avoid known hydration mismatches", async () => {
  const [chart, preferences, videoManager, planner] = await Promise.all([
    readFile(new URL("../components/app/PerformanceChart.tsx", import.meta.url), "utf8"),
    readFile(new URL("../components/app/PreferenceToggles.tsx", import.meta.url), "utf8"),
    readFile(new URL("../components/app/VideoManager.tsx", import.meta.url), "utf8"),
    readFile(new URL("../components/app/PlannerBoard.tsx", import.meta.url), "utf8"),
  ]);
  assert.doesNotMatch(chart, /toLocaleDateString\(\)/);
  assert.doesNotMatch(videoManager, /useState<Draft>\(\(\) => savedDraft/);
  assert.doesNotMatch(preferences, /useState\(\(\) => typeof window|setState\(.*useEffect/s);
  assert.doesNotMatch(planner, /toLocaleDateString\(\)/);
});

test("Galaxy S25 sized screens receive a final narrow-phone layout", async () => {
  const css = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
  assert.match(css, /Galaxy S25 and narrow Android portrait layout/);
  assert.match(css, /@media \(max-width: 430px\)/);
  assert.match(css, /\.sidebar \{ display: none; \}/);
  assert.match(css, /\.metric-grid \{ grid-template-columns: minmax\(0,1fr\); \}/);
  assert.match(css, /safe-area-inset-bottom/);
});

test("authenticated workspace never substitutes demo channel data", async () => {
  const source = await readFile(new URL("../app/dashboard/page.tsx", import.meta.url), "utf8");
  assert.doesNotMatch(source, /Demo Channel|lib\/demo/);
  assert.match(source, /No sample channel data is substituted/);
  assert.match(source, /Real public YouTube data/);
  assert.match(source, /Private metadata is marked unavailable/);
  assert.match(source, /CreatorPulse derived/);
});

test("YouTube synchronization paginates uploads and requests a 365-day analytics window", async () => {
  const source = await readFile(new URL("../lib/youtube/sync.ts", import.meta.url), "utf8");
  assert.match(source, /MAX_SYNCED_VIDEOS\s*=\s*500/);
  assert.match(source, /nextPageToken/);
  assert.match(source, /playlistItems/);
  assert.match(source, /start\.setUTCDate\(start\.getUTCDate\(\) - 364\)/);
  assert.match(source, /dailyViews:\s*rows\.map/);
});

test("login remains email/password first and platform identity fallback is opt-in", async () => {
  const [page, form, viewer] = await Promise.all([
    readFile(new URL("../app/login/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../components/auth/LoginForm.tsx", import.meta.url), "utf8"),
    readFile(new URL("../lib/auth/viewer.ts", import.meta.url), "utf8"),
  ]);
  assert.match(form, /Email/);
  assert.match(form, /Password/);
  assert.match(form, /Remember me/);
  assert.doesNotMatch(`${page}\n${form}`, /Continue with ChatGPT|signin-with-chatgpt/i);
  assert.match(viewer, /CREATORPULSE_ALLOW_PLATFORM_AUTH/);
  assert.match(viewer, /===\s*["']true["']/);
});

test("View Planner requires no paid AI provider", async () => {
  const [page, planner, env] = await Promise.all([
    readFile(new URL("../app/view-planner/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../lib/insights/view-planner.ts", import.meta.url), "utf8"),
    readFile(new URL("../.env.example", import.meta.url), "utf8"),
  ]);
  assert.match(page, /Zero-credit View Planner/);
  assert.match(page, /planEntitlements\[workspace\.plan\]\.viewPlannerStrategies/);
  assert.match(planner, /createViewPlan/);
  assert.doesNotMatch(env, /OPENAI_API_KEY/);
});

test("removing a channel clears the full workspace instead of only hiding its source", async () => {
  const [route, repository] = await Promise.all([
    readFile(new URL("../app/api/channel/remove/route.ts", import.meta.url), "utf8"),
    readFile(new URL("../lib/youtube/public-repository.ts", import.meta.url), "utf8"),
  ]);
  assert.match(route, /removeChannelWorkspace/);
  assert.match(route, /revokeGoogleToken/);
  assert.match(repository, /delete\(youtubeConnections\)/);
  assert.match(repository, /delete\(studioImports\)/);
  assert.match(repository, /delete\(plannerItems\)/);
  assert.match(repository, /delete\(channelSnapshots\)/);
  assert.match(repository, /delete\(videos\)/);
  assert.match(repository, /youtubeChannelId:\s*null/);
});

test("planner dates stay in YYYY-MM-DD form for native date inputs and display", async () => {
  const repository = await readFile(new URL("../lib/planner/repository.ts", import.meta.url), "utf8");
  assert.match(repository, /toISOString\(\)\.slice\(0, 10\)/);
  assert.match(repository, /targetDate: input\.targetDate \?\? null/);
});
