import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";

const publicSource = await import(new URL("../lib/youtube/public-source.ts", import.meta.url));
const studio = await import(new URL("../lib/youtube/studio-csv.ts", import.meta.url));

test("public channel inputs are normalized to safe fixed YouTube URLs", () => {
  assert.equal(publicSource.normalizeYouTubeChannelInput("@CreatorPulse").href, "https://www.youtube.com/@CreatorPulse");
  assert.equal(publicSource.normalizeYouTubeChannelInput("youtube.com/@CreatorPulse/ ").href, "https://www.youtube.com/@CreatorPulse");
  assert.equal(publicSource.normalizeYouTubeChannelInput("https://m.youtube.com/channel/UC1234567890123456789012?view=1").href, "https://www.youtube.com/channel/UC1234567890123456789012");
  assert.throws(() => publicSource.normalizeYouTubeChannelInput("https://example.com/@CreatorPulse"), /Only youtube.com/);
  assert.throws(() => publicSource.normalizeYouTubeChannelInput("https://youtube.com/watch?v=dQw4w9WgXcQ"), /@handle URL/);
});

test("public channel HTML becomes a normalized profile without an API", () => {
  const html = '<meta itemprop="channelId" content="UC1234567890123456789012"><meta property="og:title" content="Creator &amp; Pulse"><meta property="og:image" content="https://yt3.example/avatar.jpg"><link rel="canonical" href="https://www.youtube.com/@creatorpulse"><script>{"subscriberCountText":{"simpleText":"1.2M subscribers"},"viewCount":"42000000","videoCount":"88"}</script>';
  const profile = publicSource.parsePublicChannelHtml(html, new URL("https://www.youtube.com/@creatorpulse"));
  assert.deepEqual(profile, { channelId: "UC1234567890123456789012", title: "Creator & Pulse", handle: "@creatorpulse", avatarUrl: "https://yt3.example/avatar.jpg", canonicalUrl: "https://www.youtube.com/@creatorpulse", subscribers: 1_200_000, totalViews: 42_000_000, uploadCount: 88 });
});

test("Studio CSV parses quoted titles and deep metrics", () => {
  const csv = 'Video,Video title,Views,Watch time (hours),Subscribers,Impressions,Impressions click-through rate (%),Average view duration,Average percentage viewed (%)\nabcDEF123_4,"A title, with comma",1200,12.5,7,20000,6.4,3:15,48.2';
  const result = studio.parseStudioCsv(csv);
  assert.equal(result.rows.length, 1);
  assert.equal(result.rows[0].video.id, "abcDEF123_4");
  assert.equal(result.rows[0].video.title, "A title, with comma");
  assert.equal(result.rows[0].watchMinutes, 750);
  assert.equal(result.rows[0].impressionsCtrBasisPoints, 640);
  assert.equal(result.rows[0].averageViewDurationSeconds, 195);
  assert.equal(result.rows[0].averagePercentageViewedBasisPoints, 4820);
});

test("public analysis routes do not require Google configuration", async () => {
  const analyze = await readFile(new URL("../app/api/channel/analyze/route.ts", import.meta.url), "utf8");
  const setup = await readFile(new URL("../app/channel-setup/page.tsx", import.meta.url), "utf8");
  assert.match(analyze, /analyzePublicChannel/);
  assert.doesNotMatch(analyze, /GOOGLE_CLIENT|YOUTUBE_API|oauth/i);
  assert.match(setup, /public channel/);
  assert.match(setup, /does not claim or verify ownership/);
});
